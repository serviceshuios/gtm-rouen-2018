package fr.bovoyage.metier.objet;

import java.util.ArrayList;
import java.util.List;

public class Destination {
	private long id;
	private String region;
	private String description;
	private String image; // nom des images associées à la destination

	List<DatesVoyage> datesvoyages = new ArrayList<>();

	/**
	 * @param region
	 * @param description
	 * @param image
	 * @param id
	 * @param datesvoyages
	 */
	public Destination(long id, String region, String description, String image, List<DatesVoyage> datesvoyages) {

		this.region = region;
		this.description = description;
		this.image = image;
		this.id = id;
		this.datesvoyages = datesvoyages;
	}

	/**
	 * @param region
	 * @param description
	 * @param image
	 * @param id
	 */
	public Destination(long id, String region, String description, String image) {

		this.region = region;
		this.description = description;
		this.image = image;
		this.id = id;
	}

	/**
	 * @param region
	 * @param description
	 * @param image
	 */
	public Destination(String region, String description, String image) {
		super();
		this.region = region;
		this.description = description;
		this.image = image;
	}

	/**
	 * @param region
	 * @param description
	 * @param image
	 * @param datesvoyages
	 */
	public Destination(String region, String description, String image, List<DatesVoyage> datesvoyages) {
		super();
		this.region = region;
		this.description = description;
		this.image = image;
		this.datesvoyages = datesvoyages;
	}

	/**
	 * constructor Destination with empty fields
	 */
	public Destination() {

	}

	/**
	 * @return the region
	 */
	public String getRegion() {
		return region;
	}

	/**
	 * @param region
	 *            the region to set
	 */
	public void setRegion(String region) {
		this.region = region;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the image
	 */
	public String getImage() {
		return image;
	}

	/**
	 * @param image
	 *            the image to set
	 */
	public void setImage(String image) {
		this.image = image;
	}

	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(long id) {
		this.id = id;
	}
	
	/**
	 * 
	 * @param datesvoyage
	 */
	public void addDatesVoyage(DatesVoyage datesvoyage) {

		// datesvoyage.setId(getId());
		datesvoyages.add(datesvoyage);
	}
	/**
	 * 
	 * @return List DatesVoyages
	 */
	public List<DatesVoyage> getDatesVoyages() {

		return datesvoyages;
	}

}
