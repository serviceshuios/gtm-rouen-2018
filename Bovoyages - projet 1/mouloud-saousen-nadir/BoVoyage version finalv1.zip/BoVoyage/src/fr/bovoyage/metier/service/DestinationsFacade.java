package fr.bovoyage.metier.service;

import java.util.List;

import fr.bovoyage.dao.DestinationDAO;
import fr.bovoyage.dao.DestinationMockDAO;
import fr.bovoyage.metier.objet.DatesVoyage;
import fr.bovoyage.metier.objet.Destination;

public class DestinationsFacade {

	DestinationDAO dao = new DestinationMockDAO();

	/**
	 * @return List Destination
	 */
	public List<Destination> getAllDestinations() {
		return dao.getAlldestination();

	}

	/**
	 * @param d Destination
	 * @return List DatesVoyage 
	 */
	public List<DatesVoyage> getDatesVoyage(Destination d) {
		return dao.getDatesVoyages(d);

	}

	/**
	 * @param region
	 * @return List DatesVoyage from the same region
	 */
	public List<Destination> getsDestinationByRegion(String region) {

		return dao.getDestinationByRegion(region);

	}

	/**
	 * @param d Destination
	 * @return List DatesVoyage  
	 */
	public List<DatesVoyage> getDatesVoyages(Destination d) {

		return dao.getDatesVoyages(d);

	}
}
