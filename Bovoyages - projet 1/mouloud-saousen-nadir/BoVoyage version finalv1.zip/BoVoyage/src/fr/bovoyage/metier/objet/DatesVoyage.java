package fr.bovoyage.metier.objet;

import java.util.Date;

public class DatesVoyage {
	
	private Date dateAller;
	private Date dateRetour;
	private double tarifUnitaireHT;
	private long id;
	
	
	/**
	 * @param id
	 * @param tarifUnitaireHT
	 * 
	 */
	public DatesVoyage(long id, double tarifUnitaireHT) {
		this.id = id;
		this.tarifUnitaireHT = tarifUnitaireHT;
		
	}
	
	
	/**
	 * @param dateAller
	 * @param dateRetour
	 * @param tarifUnitaireHT
	 */
	public DatesVoyage(Date dateAller, Date dateRetour, double tarifUnitaireHT) {
		
		this.dateAller = dateAller;
		this.dateRetour = dateRetour;
		this.tarifUnitaireHT = tarifUnitaireHT;
	}


	/**
	 * @param tarifUnitaireHT
	 */
	public DatesVoyage(double tarifUnitaireHT) {
	
		this.tarifUnitaireHT = tarifUnitaireHT;
	}


	/**
	 * constructor with empty field
	 */
	public DatesVoyage() {
		
	}


	/**
	 * @return the dateAller
	 */
	public Date getDateAller() {
		return dateAller;
	}
	/**
	 * @param dateAller the dateAller to set
	 */
	public void setDateAller(Date dateAller) {
		this.dateAller = dateAller;
	}
	/**
	 * @return the dateRetour
	 */
	public Date getDateRetour() {
		return dateRetour;
	}
	/**
	 * @param dateRetour the dateRetour to set
	 */
	public void setDateRetour(Date dateRetour) {
		this.dateRetour = dateRetour;
	}
	/**
	 * @return the tarifUnitaireHT
	 */
	public double getTarifUnitaireHT() {
		return tarifUnitaireHT;
	}
	/**
	 * @param tarifUnitaireHT the tarifUnitaireHT to set
	 */
	public void setTarifUnitaireHT(double tarifUnitaireHT) {
		this.tarifUnitaireHT = tarifUnitaireHT;
	}
	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(long id) {
		this.id = id;
	}

}
