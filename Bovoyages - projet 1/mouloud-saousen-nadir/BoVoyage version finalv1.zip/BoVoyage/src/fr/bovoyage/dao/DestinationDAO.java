package fr.bovoyage.dao;

import fr.bovoyage.metier.objet.DatesVoyage;
import fr.bovoyage.metier.objet.Destination;

import java.util.List;

/**
 * @author Mouloud,Saousen, Nadir
 *  Create DAO Interface from Destination 
 * @version 1
 * 
 */
public interface DestinationDAO {
	/**
	 * Method that add element Destination on database
	 * @param d Destination
	 */
    public void create(Destination d);
    /**
	 * Method that delete element destination on database
	 * @param d Destination
	 */
    public void delete(Destination d);
    /**
     * Method that update element destination on database
     * @param d Destination
     */
    public void  update (Destination d);

    /**
     * 
     * @param region String
     * @return List Destination
     */
    public List<Destination> getDestinationByRegion(String region);
    /**
     * Method that search element destination on database with id
     * @param id
     * @return element destination on Database
     */
    public Destination getDestinationById(long id);
    /**
     * 
     * @param d Destination
     * @return the List DatesVoyage 
     */
    public List<DatesVoyage> getDatesVoyages(Destination d);
    /**
     * 
     * @return List of all Destination on datatbase
     */
    public List<Destination>  getAlldestination();


}
