
package fr.bovoyage.dao;
import fr.bovoyage.metier.objet.DatesVoyage;
import fr.bovoyage.metier.objet.Destination;
import fr.bovoyage.dao.DestinationDAO;

import java.util.ArrayList;
import java.util.List;

/**
 * @author nb
 * Create DAO Mock Destination class with interface Destination DAO
 *
 */
public class DestinationMockDAO implements DestinationDAO {
	
    private static long  id =0;
    
    private List<Destination> destinationList = new ArrayList<>();
	
	@Override
    public void create(Destination d) {
			
			
    			d.setId(getId());
            destinationList.add(d);
            setId(id);
            
    }

    private static long getId() {
		
		return id;
	}

	private static void setId(long id) {
		
		DestinationMockDAO.id +=1; // incrementation de id a chaque creation
									//dans la base de donne liste Destination
	}

	/* (non-Javadoc)
	 * @see fr.bovoyage.dao.DestinationDAO#delete(fr.bovoyage.metier.objet.Destination)
	 */
	@Override
    public void delete(Destination d) {
		
        destinationList.remove(d);
        d.setId(0); // remise à zero de id destination après suppression 
        				// dans la base de donnée
        
    }
	
	/* (non-Javadoc)
	 * @see fr.bovoyage.dao.DestinationDAO#update(fr.bovoyage.metier.objet.Destination)
	 */
	@Override
	public void update(Destination d) {
		for (Destination destination : destinationList) {
			if (destination.getId() == d.getId()) {
				destination.setDescription(d.getDescription());
				destination.setImage(d.getImage());
				destination.setRegion(d.getRegion());
			}
		}

	}

    /* (non-Javadoc)
     * @see fr.bovoyage.dao.DestinationDAO#getDestinationByRegion(java.lang.String)
     */
    @Override
    public List<Destination> getDestinationByRegion(String region) {
        List<Destination> destinationsRegion = new ArrayList<>();
       
        for (Destination destination :destinationList) {        	
			if (destination.getRegion()==region) {
				destinationsRegion.add(destination);
			}			
		}    
        
        return destinationsRegion;
    }

    /* (non-Javadoc)
     * @see fr.bovoyage.dao.DestinationDAO#getDestinationById(long)
     */
    @Override
    public Destination getDestinationById(long id) {       
    	for (Destination destination : destinationList) {
			if(destination.getId() == id) {
				return destination;
			}
		}    	
    	
        return null;
    }

    /* (non-Javadoc)
     * @see fr.bovoyage.dao.DestinationDAO#getDatesVoyages(fr.bovoyage.metier.objet.Destination)
     */
    @Override
    public List<DatesVoyage> getDatesVoyages(Destination d) {        
        for (Destination destination : destinationList) {        	
        	if (destination.getId() == d.getId() ) {
				return destination.getDatesVoyages();
			}			
		}        
        return null;
    }

    /* (non-Javadoc)
     * @see fr.bovoyage.dao.DestinationDAO#getAlldestination()
     */
    @Override
    public List<Destination> getAlldestination() {
        return destinationList;
    }

    /**
	 * @return the destinationList
	 */
	public List<Destination> getDestinationList() {
		return destinationList;
	}

	/**
	 * @param destinationList the destinationList to set
	 */
	public void setDestinationList(List<Destination> destinationList) {
		this.destinationList = destinationList;
	}
	
}
