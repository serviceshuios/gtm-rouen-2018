package fr.bovoyage.dao;

import fr.bovoyage.metier.objet.Voyage;
/**
 * 
 * @author Mouloud,Saousen, Nadir
 *  Create DAO Interface from Voyage 
 *  @version 1
 */
public interface VoyageDAO {
	
		/**
		 * Method that add element voyage on database
		 * @param v Voyage
		 */
		public void create(Voyage v);
		/**
		 * Method that delete element voyage on database
		 * @param v Voyage
		 */
	    public void delete(Voyage v);
	    /**
	     * Method that update element voyage on database
	     * @param v Voyage
	     */
	    public void  update (Voyage v);
	    /**
	     * Method that search element voyage on database with id
	     * @param id long
	     * @return element voyage on Database
	     */
	    public Voyage getVoyageById(long id);
}
