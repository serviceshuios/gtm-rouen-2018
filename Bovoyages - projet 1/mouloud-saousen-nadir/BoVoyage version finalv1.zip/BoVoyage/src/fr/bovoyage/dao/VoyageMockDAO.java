package fr.bovoyage.dao;

import java.util.ArrayList;
import java.util.List;

import fr.bovoyage.metier.objet.Voyage;

public class VoyageMockDAO implements VoyageDAO {

	private static long id = 0;

	private List<Voyage> voyageList = new ArrayList<>();

	/**
	 * @return the voyageList
	 */
	public List<Voyage> getVoyageList() {
		return voyageList;
	}

	/**
	 * @param voyageList
	 *        the voyageList to set
	 */
	public void setVoyageList(List<Voyage> voyageList) {
		this.voyageList = voyageList;
	}

	@Override
	public void create(Voyage v) {
		setId(id);
		v.setId(id);
		voyageList.add(v);
	}

	@Override
	public void delete(Voyage v) {
		voyageList.remove(v);

	}

	@Override
	public void update(Voyage v) {

		for (Voyage voyage : voyageList) {
			if (voyage.getId() == v.getId()) {
				voyage.setDescription(v.getDescription());
				voyage.setRegion(v.getRegion());
			}
		}
	}

	@Override
	public Voyage getVoyageById(long id) {
		for (Voyage voyage : voyageList) {
			if (voyage.getId() == id) {
				return voyage;
			}
		}

		return null;
	}

	/**
	 * @return the id
	 */
	public static long getId() {
		return id;
	}

	/**
	 * @param id
	 *        the id to set
	 */
	public static void setId(long id) {
		VoyageMockDAO.id += 1;
	}

}
