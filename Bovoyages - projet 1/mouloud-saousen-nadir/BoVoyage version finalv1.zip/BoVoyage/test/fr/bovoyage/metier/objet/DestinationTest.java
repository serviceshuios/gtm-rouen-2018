package fr.bovoyage.metier.objet;

import static org.junit.Assert.*;

import org.junit.Test;

public class DestinationTest {

	
	Destination destination = new Destination(3,"Normandie"," ville de rêve, voir et à revoir, voire vivre","normandie.jpg");

	@Test
	public void testGetRegion() {
		
		assertEquals("Normandie", destination.getRegion());
		
	}

	@Test
	public void testSetRegion() {
		destination.setRegion("Normandie");
		assertEquals("Normandie", destination.getRegion());
	}


	@Test
	public void testGetId() {
		assertEquals(3,destination.getId());
	}

	@Test
	public void testSetId() {
		destination.setId(6);
		assertEquals(6,destination.getId());
	}

	@Test
	public void testAddDatesVoyage() {
		
		DatesVoyage datesVoyage1 = new DatesVoyage();
        DatesVoyage datesVoyage2 = new DatesVoyage();

        destination.addDatesVoyage(datesVoyage1);
        destination.addDatesVoyage(datesVoyage2);
        
        assertEquals(datesVoyage1.getTarifUnitaireHT(),destination.getDatesVoyages().get(0).getTarifUnitaireHT(),0);
        assertEquals(datesVoyage2.getTarifUnitaireHT(),destination.getDatesVoyages().get(1).getTarifUnitaireHT(),0);

	}

	@Test
	public void testGetDatesVoyages() {
		
		DatesVoyage datesVoyage1 = new DatesVoyage();
        DatesVoyage datesVoyage2 = new DatesVoyage();

        destination.addDatesVoyage(datesVoyage1);
        destination.addDatesVoyage(datesVoyage2);
        
        assertEquals(datesVoyage1,destination.getDatesVoyages().get(0));
        assertEquals(datesVoyage2,destination.getDatesVoyages().get(1));        
		
	}

}
