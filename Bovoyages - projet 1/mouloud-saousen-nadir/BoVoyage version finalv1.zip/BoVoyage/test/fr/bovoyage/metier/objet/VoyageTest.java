/**
 * 
 */
package fr.bovoyage.metier.objet;

import static org.junit.Assert.*;


import org.junit.Test;

/**
 * @author Adminl
 *
 */
public class VoyageTest {
	

			
	
	Voyage voyage=new Voyage(3,"Normandie","toitototntotjotuotjotuotoutot");
	Voyageur participant1 = new Voyageur("TOTO1");
	Voyageur participant2 = new Voyageur("TOTO3");
	DatesVoyage datesVoyage= new DatesVoyage(345);
	
	
	


	/**
	 * Test method for {@link fr.bovoyage.metier.objet.Voyage#getRegion()}.
	 */
	@Test
	public void testGetRegion() {

		assertEquals(voyage.getRegion(), "Normandie");
	}

	/**
	 * Test method for {@link fr.bovoyage.metier.objet.Voyage#setRegion(java.lang.String)}.
	 */
	@Test
	public void testSetRegion() {
		voyage.setRegion("region");
		assertEquals(voyage.getRegion(),"region" );
	}

	

	/**
	 * Test method for {@link fr.bovoyage.metier.objet.Voyage#getPrixTotalHT(fr.bovoyage.metier.objet.DatesVoyage)}.
	 */
	@Test
	public void testGetPrixTotalHT() {
		
		voyage.addParticipant(participant1);
		voyage.addParticipant(participant2);
		
		double prix = voyage.getPrixTotalHT(datesVoyage);

		assertEquals(690, prix,0);
	
	}

	/**
	 * Test method for {@link fr.bovoyage.metier.objet.Voyage#addParticipant(fr.bovoyage.metier.objet.Voyageur)}.
	 */
	@Test
	public void testAddParticipant() {
		voyage.addParticipant(participant1);
		assertEquals(participant1, voyage.getAllParticipant().get(0));
	}

	

}
