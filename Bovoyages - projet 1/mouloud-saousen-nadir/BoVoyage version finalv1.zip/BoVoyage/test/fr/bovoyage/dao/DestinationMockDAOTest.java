package fr.bovoyage.dao;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import fr.bovoyage.metier.objet.DatesVoyage;
import fr.bovoyage.metier.objet.Destination;

public class DestinationMockDAOTest {

	Destination destination1 = new Destination();
	Destination destination2 = new Destination();

	DestinationMockDAO dmO = new DestinationMockDAO();

	@Test
	public void testCreate() {
		
		dmO.create(destination1);
		assertEquals(destination1.getId(), dmO.getDestinationList().get(0).getId());
		
		dmO.create(destination2);
		assertEquals(destination2.getId(), dmO.getDestinationList().get(1).getId());
		
	}

	@Test
	public void testDelete() {
		
		dmO.create(destination1);
		dmO.create(destination2);
		dmO.delete(destination1);
		
		
		assertEquals(1, dmO.getDestinationList().size());
		assertEquals(0, destination1.getId());
	}

	@Test
	public void testUpdate() {
		
		dmO.create(destination1);
		destination1.setRegion("nONO");
		dmO.update(destination1);
		assertEquals(dmO.getDestinationList().get(0).getRegion(), destination1.getRegion());
	}

	@Test
	public void testGetDestinationByRegion() {
		
		List<Destination> dest = new ArrayList<>();
		destination1.setRegion("nONO");
		dmO.create(destination1);
		destination2.setRegion("uuu");
		dmO.create(destination2);

		dest = dmO.getDestinationByRegion(destination1.getRegion());

		assertEquals(destination1.getRegion(), dest.get(0).getRegion());
	}

	@Test
	public void testGetDestinationById() {
		
		destination1.setRegion("nONO");
		dmO.create(destination1);
		destination2.setRegion("uuu");
		dmO.create(destination2);

		assertEquals(destination1.getId(), dmO.getDestinationList().get(0).getId());
	}

	@Test
	public void testGetDatesVoyages() {
		
		DatesVoyage datesVoyage1 = new DatesVoyage(600);
		destination1.addDatesVoyage(datesVoyage1);
		dmO.create(destination1);
		DatesVoyage datesVoyage2 = new DatesVoyage(500);
		destination2.addDatesVoyage(datesVoyage2);

		dmO.create(destination2);

		assertEquals(destination1.getDatesVoyages().get(0).getTarifUnitaireHT(),
				dmO.getDestinationList().get(0).getDatesVoyages().get(0).getTarifUnitaireHT(), 0);
	}

	@Test
	public void testGetAlldestination() {
		
		DatesVoyage datesVoyage1 = new DatesVoyage(600);
		destination1.addDatesVoyage(datesVoyage1);
		dmO.create(destination1);
		DatesVoyage datesVoyage2 = new DatesVoyage(500);
		destination2.addDatesVoyage(datesVoyage2);
		dmO.create(destination2);
		assertEquals(destination1, dmO.getAlldestination().get(0));
		assertEquals(destination2, dmO.getAlldestination().get(1));
	}

}
