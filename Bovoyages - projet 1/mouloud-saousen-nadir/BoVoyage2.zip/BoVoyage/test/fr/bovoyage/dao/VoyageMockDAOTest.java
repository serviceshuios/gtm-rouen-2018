package fr.bovoyage.dao;

import static org.junit.Assert.*;

import org.junit.Test;

import fr.bovoyage.metier.objet.Voyage;

public class VoyageMockDAOTest {
	
	Voyage voyage1 = new Voyage();
	Voyage voyage2 = new Voyage();
	

	VoyageMockDAO vmO = new VoyageMockDAO();

	@Test
	public void testCreate() {
		vmO.create(voyage1);
		assertEquals(voyage1.getId(),vmO.getVoyageList().get(0).getId());		
		System.out.println(voyage1.getId());
		vmO.create(voyage2);
		assertEquals(voyage2.getId(),vmO.getVoyageList().get(1).getId());
	
	}

	@Test
	public void testDelete() {
		vmO.create(voyage1);
		vmO.create(voyage2);
		
		vmO.delete(voyage1);
		
		assertEquals(1,vmO.getVoyageList().size());
	}

	@Test
	public void testUpdate() {
		vmO.create(voyage1);
		voyage1.setRegion("nONO");
		vmO.update(voyage1);
		assertEquals(vmO.getVoyageList().get(0).getRegion(), voyage1.getRegion());
	}

	@Test
	public void testGetVoyageById() {

		voyage1.setRegion("nONO");
		vmO.create(voyage1);
		voyage2.setRegion("uuu");
		vmO.create(voyage2);		
		
		assertEquals(voyage1.getId(),vmO.getVoyageList().get(0).getId());
	}

}
