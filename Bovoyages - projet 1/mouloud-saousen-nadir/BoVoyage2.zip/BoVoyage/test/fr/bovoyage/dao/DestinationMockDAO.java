
package fr.bovoyage.dao;
import fr.bovoyage.metier.objet.DatesVoyage;
import fr.bovoyage.metier.objet.Destination;
import fr.bovoyage.dao.DestinationDAO;

import java.util.ArrayList;
import java.util.List;

public class DestinationMockDAO implements DestinationDAO {
	
    private static long  id =0;
    
    private List<Destination> destinationList = new ArrayList<>();

    /**
	 * @return the destinationList
	 */
	public List<Destination> getDestinationList() {
		return destinationList;
	}

	/**
	 * @param destinationList the destinationList to set
	 */
	public void setDestinationList(List<Destination> destinationList) {
		this.destinationList = destinationList;
	}

	@Override
    public void create(Destination d) {
			setId(id);
    		d.setId(getId());
            destinationList.add(d);
    }

    private static long getId() {
		// TODO Auto-generated method stub
		return id;
	}

	private static void setId(long id) {
		// TODO Auto-generated method stub
		DestinationMockDAO.id +=1;
	}

	@Override
    public void delete(Destination d) {
        destinationList.remove(d);
    }

    @Override
    public void update(Destination d) {    	
    	for (Destination destination : destinationList) {
			if (destination.getId() == d.getId()) {
				destination.setDescription(d.getDescription());
				destination.setImage(d.getImage());
				destination.setRegion(d.getRegion());
			}
		}    	
    	
    }

    @Override
    public List<Destination> getDestinationByRegion(String region) {
        List<Destination> destinationsRegion = new ArrayList<>();
       
        for (Destination destination :destinationList) {        	
			if (destination.getRegion()==region) {
				destinationsRegion.add(destination);
			}			
		}    
        
        return destinationsRegion;
    }

    @Override
    public Destination getDestinationById(long id) {       
    	for (Destination destination : destinationList) {
			if(destination.getId() == id) {
				return destination;
			}
		}    	
    	
        return null;
    }

    @Override
    public List<DatesVoyage> getDatesVoyages(Destination d) {        
        for (Destination destination : destinationList) {        	
        	if (destination.getId() == d.getId() ) {
				return destination.getDatesVoyages();
			}			
		}        
        return null;
    }

    @Override
    public List<Destination> getAlldestination() {
        return destinationList;
    }
	
}
