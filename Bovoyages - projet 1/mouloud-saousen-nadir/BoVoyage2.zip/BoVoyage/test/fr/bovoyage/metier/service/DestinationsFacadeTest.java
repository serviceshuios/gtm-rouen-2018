package fr.bovoyage.metier.service;

import static org.junit.Assert.*;

import org.junit.Test;

public class DestinationsFacadeTest {

	@Test
	public void testGetAllDestinations() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetDatesVoyage() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetsDestinationByRegion() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetDatesVoyages() {
		fail("Not yet implemented");
	}

}
