package fr.bovoyage.metier.objet;

import static org.junit.Assert.*;

import org.junit.Test;

public class ClientTest {

	Client client = new Client(1,"Nadir");
	@Test
	public void testGetNom() {
		String nom= client.getNom();
		assertEquals("Nadir", nom);
	}

	@Test
	public void testSetNom() {
		client.setNom("Toto");
		assertEquals("Toto", client.getNom());
	}

	@Test
	public void testGetId() {
		
		long id=client.getId();
		assertEquals(1, id);
	}

	@Test
	public void testSetId() {
		
		client.setId(3);
		
		assertEquals(3, client.getId());
	}

}
