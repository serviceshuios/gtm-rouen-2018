package fr.bovoyage.metier.objet;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.Test;

public class DatesVoyageTest {
	
	DatesVoyage datesVoyage = new DatesVoyage(3,560);
	
	@Test
	public void testGetTarifUnitaireHT() {
		double tarif=datesVoyage.getTarifUnitaireHT();
		assertEquals(560, tarif,0);
		
	}

	@SuppressWarnings("deprecation")
	@Test
	public void testSetTarifUnitaireHT() {
		datesVoyage.setTarifUnitaireHT(590);
		assertEquals(590,datesVoyage.getTarifUnitaireHT(),0);
	}

	@Test
	public void testGetId() {
		long id=datesVoyage.getId();
		assertEquals(3, id);
	}

	@Test
	public void testSetId() {
		datesVoyage.setId(7);
		assertEquals(7, datesVoyage.getId());
	}

}
