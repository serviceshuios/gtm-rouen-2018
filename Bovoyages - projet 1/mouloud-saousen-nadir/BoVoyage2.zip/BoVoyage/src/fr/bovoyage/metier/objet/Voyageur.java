package fr.bovoyage.metier.objet;

import java.util.Date;

public class Voyageur {
	private String civilite;
	private String nom;
	private String prenom;
	private Date dateNaissance;
	private long id;
	
	
	
	/**
	 * 
	 */
	public Voyageur() {
		
	}
	/**
	 * @param id
	 * @param civilite
	 * @param nom
	 * @param prenom
	 * @param dateNaissance
	 * 
	 */
	public Voyageur(long id,String civilite, String nom, String prenom, Date dateNaissance) {
		this.id = id;
		this.civilite = civilite;
		this.nom = nom;
		this.prenom = prenom;
		this.dateNaissance = dateNaissance;
		
	}
	
	
	/**
	 * @param civilite
	 * @param nom
	 * @param prenom
	 * @param dateNaissance
	 */
	public Voyageur(String civilite, String nom, String prenom, Date dateNaissance) {
		
		this.civilite = civilite;
		this.nom = nom;
		this.prenom = prenom;
		this.dateNaissance = dateNaissance;
	}
	/**
	 * @param nom
	 */
	public Voyageur(String nom) {
		
		this.nom = nom;
	}
	/**
	 * @return the civilite
	 */
	public String getCivilite() {
		return civilite;
	}
	/**
	 * @param civilite the civilite to set
	 */
	public void setCivilite(String civilite) {
		this.civilite = civilite;
	}
	/**
	 * @return the nom
	 */
	public String getNom() {
		return nom;
	}
	/**
	 * @param nom the nom to set
	 */
	public void setNom(String nom) {
		this.nom = nom;
	}
	/**
	 * @return the prenom
	 */
	public String getPrenom() {
		return prenom;
	}
	/**
	 * @param prenom the prenom to set
	 */
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	/**
	 * @return the dateNaissance
	 */
	public Date getDateNaissance() {
		return dateNaissance;
	}
	/**
	 * @param dateNaissance the dateNaissance to set
	 */
	public void setDateNaissance(Date dateNaissance) {
		this.dateNaissance = dateNaissance;
	}
	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(long id) {
		this.id = id;
	}
	
	
}
