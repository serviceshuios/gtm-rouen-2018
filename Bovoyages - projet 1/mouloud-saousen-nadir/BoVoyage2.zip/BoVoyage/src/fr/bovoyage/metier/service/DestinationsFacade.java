package fr.bovoyage.metier.service;



import java.util.List;


import fr.bovoyage.dao.DestinationDAO;
import fr.bovoyage.dao.DestinationMockDAO;
import fr.bovoyage.metier.objet.DatesVoyage;
import fr.bovoyage.metier.objet.Destination;



public class DestinationsFacade {
	
	DestinationDAO dao = new DestinationMockDAO();

	
	public List<Destination> getAllDestinations() {
		return dao.getAlldestination();
		

	}
	public List<DatesVoyage> getDatesVoyage(Destination d) {
		return dao.getDatesVoyages(d);
		

	}
	public List<Destination> getsDestinationByRegion(String region) {
		
		
		return dao.getDestinationByRegion(region);
		

	}
	public List<DatesVoyage> getDatesVoyages(Destination d) {
		
		return dao.getDatesVoyages(d);
		

	}
}
