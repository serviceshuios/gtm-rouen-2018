package fr.bovoyage.metier.objet;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Adminl
 *
 */
public class Voyage {
	
	private static final int NB_PARTICIPANT = 9;
	
	private long id ;
	private String region;
	private String description;
	
	
	private List<Voyageur> participants = new ArrayList<>(NB_PARTICIPANT);	
	
	private Client client = new Client();	
	
	private DatesVoyage datesvoyage = new DatesVoyage();
			
	
	
	/**
	 * 
	 */
	public Voyage() {
	
	}


	/**
	 * @param region
	 * @param description
	 */
	public Voyage(String region, String description) {
	
		this.region = region;
		this.description = description;
	}


	/**
	 * @param id
	 * @param region
	 * @param description
	 * @param participants
	 * @param client
	 * @param datesvoyage
	 */
	public Voyage(long id,String region, String description,  List<Voyageur> participants, Client client,
			DatesVoyage datesvoyage) {

		this.id = id;
		this.region = region;
		this.description = description;
		this.participants = participants;
		this.client = client;
		this.datesvoyage = datesvoyage;
	}
	
	
	/**
	 * @param id
	 * @param region
	 * @param description
	 * @param participants
	 */
	public Voyage(long id,String region, String description,List<Voyageur> participants) {
		this.id = id;
		this.region = region;
		this.description = description;		
		this.participants = participants;
	}

	

	/**
	 * @param id
	 * @param region
	 * @param description
	 * @param participants
	 * @param datesvoyage
	 */
	public Voyage(long id,String region, String description,  List<Voyageur> participants, DatesVoyage datesvoyage) {
		this.id = id;
		this.region = region;
		this.description = description;		
		this.participants = participants;
		this.datesvoyage = datesvoyage;
	}

	


	/**
	 * @param id
	 * @param region
	 * @param description
	 *
	 */
	public Voyage(long id,String region, String description) {	
		this.region = region;
		this.description = description;
		this.id = id;
	}


	/**
	 * @return the region
	 */
	public String getRegion() {
		return region;
	}
	/**
	 * @param region the region to set
	 */
	public void setRegion(String region) {
		this.region = region;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */

	public void setId(long id) {
		this.id = id;
	}
	
	public double getPrixTotalHT(DatesVoyage datesVoyage) {
		
		double PrixTotalHT= participants.size()*datesVoyage.getTarifUnitaireHT();
		
		return PrixTotalHT;
	}
		
	/**
	 * 
	 * @param participant
	 */
	public void addParticipant(Voyageur participant) {
		
		participants.add(participant);
	}
	
	/**
	 * 
	 * @param participants
	 */
	public void SetParticipants(List<Voyageur>  participants) {
		
		this.participants=participants;
	}
	/**
	 * 
	 * @return List voyageur
	 */
	public List<Voyageur> getAllParticipant() {
		
		return participants;
	}
	
	
	/**
	 * 
	 * @param client return client
	 */
	public void setClient(Client client) {
		this.client=client;
	}
	/**
	 * 
	 * @return client
	 */
	public Client getClient(){
	  
		return client;
	   }
	
	/**
	 * @return the datesvoyage
	 */
	public DatesVoyage getDatesvoyage() {
		return datesvoyage;
	}
	/**
	 * @param datesvoyage the DatesVoyage to set
	 */
	public void setDatesVoyage(DatesVoyage datesvoyage) {
		this.datesvoyage = datesvoyage;
	}
	 
	
}
