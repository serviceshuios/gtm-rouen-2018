package fr.bovoyage.metier.objet;

public class Client {
	private String nom;
	private long id ;
	
	/**
	 * 
	 * @param id
	 * @param nom
	 */
	public Client(long id,String nom) {		
		this.nom = nom;
		this.id=id;
	}	

	/**
	 * 
	 * @param nom
	 */
	public Client(String nom) {
		this.nom = nom;
	}
	public Client() {
		
	}
	/**
	 * @return the nom
	 */
	public String getNom() {
		return nom;
	}
	/**
	 * @param nom the nom to set
	 */
	public void setNom(String nom) {
		this.nom = nom;
	}
	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(long id) {
		this.id = id;
	}
	
}
