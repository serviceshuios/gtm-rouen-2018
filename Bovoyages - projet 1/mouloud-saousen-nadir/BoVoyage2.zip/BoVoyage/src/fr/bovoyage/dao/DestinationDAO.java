package fr.bovoyage.dao;

import fr.bovoyage.metier.objet.DatesVoyage;
import fr.bovoyage.metier.objet.Destination;

import java.util.List;

public interface DestinationDAO {

    public void create(Destination d);

    public void delete(Destination d);

    public void  update (Destination d);


    public List<Destination> getDestinationByRegion(String region);

    public Destination getDestinationById(long id);

    public List<DatesVoyage> getDatesVoyages(Destination d);

    public List<Destination>  getAlldestination();


}
