package fr.bovoyage.dao;

import fr.bovoyage.metier.objet.Voyage;

public interface VoyageDAO {
	
	
		public void create(Voyage v);

	    public void delete(Voyage v);

	    public void  update (Voyage v);
	    
	    public Voyage getVoyageById(long id);
}
