package fr.gtm.bovoyages.entities;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;

public class DestinationTest {

	@Test
	public void testDestination() {
		Destination d = new Destination();
		assertNotNull(d);
		assertEquals(0, d.getId());
	}

	@Test
	public void testDestinationStringString() {
		String region = "Antilles";
		String descriptif = "Il y fait beau";
		Destination d = new Destination(region,descriptif);
		assertNotNull(d);
		assertEquals(0, d.getId());
		assertEquals(region, d.getRegion());
		assertEquals(descriptif, d.getDescription());
	}

	@Test
	public void testSetGetId() {
		Destination d = new Destination();
		long id = 100;
		d.setId(id);
		assertEquals(id, d.getId());
	}

	@Test
	public void testAddDatesVoyage() {
		Destination d = new Destination();
		DatesVoyage dv = new DatesVoyage();
		d.addDatesVoyage(dv);
		assertEquals(1, d.getDatesVoyages().size());
		assertEquals(dv, d.getDatesVoyages().get(0));
	}

	@Test
	public void testSetGetRegion() {
		Destination d = new Destination();
		String r = "Antilles";
		d.setRegion(r);
		assertEquals(r, d.getRegion());
	}

	@Test
	public void testSetGetDescription() {
		Destination d = new Destination();
		String r = "Beau pays";
		d.setDescription(r);
		assertEquals(r, d.getDescription());
	}

	@Test
	public void testSetGetDatesVoyages() {
		Destination d = new Destination();
		DatesVoyage dv1 = new DatesVoyage();
		DatesVoyage dv2 = new DatesVoyage();
		List<DatesVoyage> dvs = Arrays.asList(new DatesVoyage[]{dv1,dv2});
		d.setDatesVoyages(dvs);
		assertEquals(dvs.size(), d.getDatesVoyages().size());
		assertEquals(dvs, d.getDatesVoyages());
	}

}
