package fr.gtm.bovoyages.entities;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.Test;

import fr.gtm.bovoyages.entities.DatesVoyage;

public class DatesVoyageTest {

	@Test
	public void testDatesVoyage() {
		DatesVoyage dv = new DatesVoyage();
		assertNotNull(dv);
		assertEquals(0, dv.getId());
	}

	@Test
	public void testDatesVoyageDateDateDouble() {
		Date d1 = new Date(2018,10,1);
		Date d2 = new Date(2018,10,7);
		double prix = 1234.5;
		DatesVoyage dv = new DatesVoyage(d1,d2,prix);
		assertNotNull(dv);
		assertEquals(d1, dv.getDateAller());
		assertEquals(d2, dv.getDateRetour());
		assertEquals(prix, dv.getPrixHT(),0);
		assertEquals(0, dv.getId());
	}

	@Test
	public void testSetGetId() {
		DatesVoyage dv = new DatesVoyage();
		long id=10;
		dv.setId(id);
		assertEquals(id, dv.getId());
	}

	@Test
	public void testSetGetDateAller() {
		DatesVoyage dv = new DatesVoyage();
		Date d = new Date(2018, 11, 1);
		dv.setDateAller(d);
		assertEquals(d, dv.getDateAller());
	}

	@Test
	public void testSetGetDateRetour() {
		DatesVoyage dv = new DatesVoyage();
		Date d = new Date(2018, 11, 1);
		dv.setDateRetour(d);
		assertEquals(d, dv.getDateRetour());
	}

	@Test
	public void testSetGetPrixHT() {
		DatesVoyage dv = new DatesVoyage();
		double prix = 1234.5;
		dv.setPrixHT(prix);
		assertEquals(prix, dv.getPrixHT(),0);
	}

}
