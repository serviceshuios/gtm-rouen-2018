package fr.gtm.bovoyages;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import fr.gtm.bovoyages.dao.DestinationDaoTest;
import fr.gtm.bovoyages.dao.VoyageDaoTest;
import fr.gtm.bovoyages.entities.*;
import fr.gtm.bovoyages.facades.DestinationFacadeTest;

@RunWith(Suite.class)
@SuiteClasses({ ClientTest.class, DatesVoyageTest.class, DestinationTest.class, VoyageTest.class, 
	VoyageurTest.class, VoyageDaoTest.class, DestinationDaoTest.class, DestinationFacadeTest.class })
public class AllTests {

}
