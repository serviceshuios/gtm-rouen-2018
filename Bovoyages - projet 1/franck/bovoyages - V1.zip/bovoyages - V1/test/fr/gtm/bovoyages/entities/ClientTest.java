package fr.gtm.bovoyages.entities;

import static org.junit.Assert.*;

import org.junit.Test;

public class ClientTest {

	@Test
	public void testClient() {
		Client c = new Client();
		assertNotNull(c);
		assertEquals(0, c.getId());
	}

	@Test
	public void testClientString() {
		String n = "Toto";
		Client c = new Client(n);
		assertNotNull(c);
		assertEquals(0, c.getId());
		assertEquals(n,c.getNom());
	}

	@Test
	public void testSetId() {
		long id = 200;
		Client c = new Client();
		c.setId(id);
		assertEquals(id, c.getId());
	}

	@Test
	public void testSetNom() {
		String n = "Toto";
		Client c = new Client();
		c.setNom(n);
		assertEquals(n, c.getNom());
	}

}
