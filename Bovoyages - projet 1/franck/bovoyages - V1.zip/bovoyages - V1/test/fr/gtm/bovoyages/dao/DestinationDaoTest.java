package fr.gtm.bovoyages.dao;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import fr.gtm.bovoyages.dao.mock.DestinationMockDAO;
import fr.gtm.bovoyages.entities.DatesVoyage;
import fr.gtm.bovoyages.entities.Destination;

public class DestinationDaoTest {
	List<Destination> destinations;
	DestinationDAO dao;
	
	@Before
	public void init() {
		dao  = new DestinationMockDAO();
		destinations = new ArrayList<>();
		List<DatesVoyage> dvs = new ArrayList<>();
		for(int i=0 ; i< 4 ; i++) {
			dvs.add(new DatesVoyage());
		}
		for(int i=0 ; i<4 ; i++) {
			Destination d = new Destination();
			d.setDatesVoyages(dvs);
			destinations.add(d);
		}
	}

	@Test
	public void testSave() {
		Destination d = new Destination();
		dao.save(d);
		assertNotEquals(0, d.getId());
	}

	@Test
	public void testDelete() {
		Destination d = new Destination();
		dao.save(d);
		long id = d.getId();
		dao.delete(d);
		d = dao.getDestinationById(id);
		assertNull(d);
	}

	@Test
	public void testUpdate() {
		Destination d = new Destination("Paris","La ville lumière");
		dao.save(d);
		long id = d.getId();
		String r = "Corse";
		d.setRegion(r);
		dao.update(d);
		assertEquals(id, d.getId());
		Destination d1 = dao.getDestinationById(id);
		assertEquals(r, d1.getRegion());
		assertEquals(d,d1);
	}

	@Test
	public void testGetDestinationsByRegion() {
		Destination d1 = new Destination("Paris","La ville lumière");
		Destination d2 = new Destination("Paris","La ville lumière");
		Destination d3 = new Destination("Lille","La ville lumière");
		dao.save(d1);
		dao.save(d2);
		dao.save(d3);
		List<Destination> dest = dao.getDestinationsByRegion("Paris");
		assertEquals(2, dest.size());
		
	}

	@Test
	public void testGetDestinationById() {
		Destination d = new Destination("Paris","La ville lumière");
		dao.save(d);
		Destination d1 = dao.getDestinationById(d.getId());
		assertNotNull(d1);
	}

	@Test
	public void testGetDatesVoyages() {
		for(Destination d : destinations) {
			dao.save(d);
		}
		List<DatesVoyage> dvs = dao.getDatesVoyages(destinations.get(0));
		assertEquals(4, dvs.size());
	}

	@Test
	public void testGetAllDestinations() {
		for(Destination d : destinations) {
			dao.save(d);
		}
		List<Destination> dest = dao.getAllDestinations();
		assertEquals(destinations.size(), dest.size());
	}

}
