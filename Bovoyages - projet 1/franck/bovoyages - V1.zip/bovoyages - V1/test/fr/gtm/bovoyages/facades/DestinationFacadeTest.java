package fr.gtm.bovoyages.facades;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import fr.gtm.bovoyages.dao.DestinationDAO;
import fr.gtm.bovoyages.dao.mock.DestinationMockDAO;
import fr.gtm.bovoyages.entities.DatesVoyage;
import fr.gtm.bovoyages.entities.Destination;

public class DestinationFacadeTest {
	
	DestinationDAO dao;
	
	@Before
	public void init() {
		dao  = new DestinationMockDAO();
		List<DatesVoyage> dvs = new ArrayList<>();
		for(int i=0 ; i< 4 ; i++) {
			dvs.add(new DatesVoyage(new Date(),new Date(),1000));
		}
		for(int i=0 ; i<4 ; i++) {
			Destination d = new Destination("Rouen","rouen");
			d.setDatesVoyages(dvs);
			dao.save(d);
		}
	}


	@Test
	public void testDestinationFacade() {
		DestinationFacade facade = new DestinationFacade(dao);
		assertNotNull(facade);
	}

	@Test
	public void testGetAllDestinations() {
		DestinationFacade facade = new DestinationFacade(dao);
		List<Destination> liste = facade.getAllDestinations();
		assertEquals(4, liste.size());
	}

	@Test
	public void testGetDatesVoyagesDestination() {
		DestinationFacade facade = new DestinationFacade(dao);
		List<Destination> liste = facade.getAllDestinations();
		List<DatesVoyage> dates = facade.getDatesVoyages(liste.get(0));
		assertEquals(4, dates.size());
	}

	@Test
	public void testGetDestinationsByRegion() {
		Destination d1 = new Destination("Paris","La ville lumière");
		Destination d2 = new Destination("Paris","La ville lumière");
		Destination d3 = new Destination("Lille","La ville lumière");
		dao.save(d1);
		dao.save(d2);
		dao.save(d3);
		
		DestinationFacade facade = new DestinationFacade(dao);
		List<Destination> liste = facade.getDestinationsByRegion("Paris");
		assertEquals(2, liste.size());
	}

	@Test
	public void testGetDatesVoyagesLong() {
		DestinationFacade facade = new DestinationFacade(dao);
		List<Destination> liste = facade.getAllDestinations();
		List<DatesVoyage> dates = facade.getDatesVoyages(liste.get(0).getId());
		assertEquals(4, dates.size());
	}

}
