package fr.gtm.bovoyages.entities;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.Test;

public class VoyageurTest {
	String c = "M";
	String n = "LAGAFFE";
	String p = "Gaston";
	Date dn = new Date(1957,1,28);
	long id = 300;
	
	@Test
	public void testVoyageur() {
		Voyageur v = new Voyageur();
		assertNotNull(v);
		assertEquals(0,v.getId());
	}

	@Test
	public void testVoyageurStringStringString() {
		Voyageur v = new Voyageur(c, n, p);
		assertNotNull(v);
		assertEquals(c, v.getCivilite());
		assertEquals(n, v.getNom());
		assertEquals(p, v.getPrenom());
		assertEquals(0, v.getId());
	}

	@Test
	public void testVoyageurStringStringStringDate() {
		Voyageur v = new Voyageur(c, n, p,dn);
		assertNotNull(v);
		assertEquals(c, v.getCivilite());
		assertEquals(n, v.getNom());
		assertEquals(p, v.getPrenom());
		assertEquals(dn, v.getDateNaissance());;
		assertEquals(0, v.getId());
	}

	@Test
	public void testSetGetId() {
		Voyageur v = new Voyageur();
		v.setId(id);
		assertEquals(id, v.getId());
	}

	@Test
	public void testSetGetCivilite() {
		Voyageur v = new Voyageur();
		v.setCivilite(c);
		assertEquals(c, v.getCivilite());
	}

	@Test
	public void testSetGetNom() {
		Voyageur v = new Voyageur();
		v.setNom(n);
		assertEquals(n, v.getNom());
	}

	@Test
	public void testSetGetPrenom() {
		Voyageur v = new Voyageur();
		v.setPrenom(p);
		assertEquals(p, v.getPrenom());
	}

	@Test
	public void testSetGetDateNaissance() {
		Voyageur v = new Voyageur();
		v.setDateNaissance(dn);
		assertEquals(dn, v.getDateNaissance());
	}

}
