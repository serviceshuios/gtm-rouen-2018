package fr.gtm.bovoyages.dao;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import fr.gtm.bovoyages.dao.mock.VoyageMockDAO;
import fr.gtm.bovoyages.entities.Client;
import fr.gtm.bovoyages.entities.DatesVoyage;
import fr.gtm.bovoyages.entities.Voyage;
import fr.gtm.bovoyages.entities.Voyageur;

public class VoyageDaoTest {
	List<Voyageur> voyageurs;
	Client c = new Client();
	DatesVoyage dv = new DatesVoyage();
	VoyageDAO dao;

	@Before
	public void setUp() throws Exception {
		voyageurs = new ArrayList<>();
		for(int i=0 ; i<5 ; i++) {
			voyageurs.add(new Voyageur("M", "foo"+i, "bar"+i));
		}
		dao = new VoyageMockDAO();
	}

	@Test
	public void testSave() {
		Voyage v = new Voyage();
		dao.save(v);
		assertNotEquals(0, v.getId());
	}

	@Test
	public void testDelete() {
		Voyage v = new Voyage();
		dao.save(v);
		long id = v.getId();
		dao.delete(v);
		v = dao.getDatesVoyageById(id);
		assertNull(v);
	}

	@Test
	public void testUpddate() {
		Voyage v = new Voyage("Paris", "Ville lumière");
		dao.save(v);
		v.setRegion("Rouen");
		Voyage v1 = dao.getDatesVoyageById(v.getId());
		assertEquals(v, v1);
		assertEquals("Rouen", v1.getRegion());
	}

	@Test
	public void testGetDatesVoyageById() {
		Voyage v = new Voyage();
		dao.save(v);
		long id = v.getId();
		Voyage v1 = dao.getDatesVoyageById(id);
		assertNotNull(v1);
		assertEquals(v, v1);
	}

}
