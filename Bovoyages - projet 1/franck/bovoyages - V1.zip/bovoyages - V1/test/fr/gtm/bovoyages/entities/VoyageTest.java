package fr.gtm.bovoyages.entities;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class VoyageTest {
	long id = 400;
	String region = "Antilles";
	String description = "Il y fait chaud !!!";
	List<Voyageur> voyageurs = new ArrayList<>();
	Voyageur v1 = new Voyageur("M", "LAGAFFE", "Gaston");
	Voyageur v2 = new Voyageur("Mme", "BLANC SEC", "Adèle");
	Client c = new Client("Toto");
	DatesVoyage dv = new DatesVoyage(new Date(2019,1,1), new Date(2019,1,10), 1000.5);
	
	@Before
	public void init() {
		voyageurs = Arrays.asList(new Voyageur[] {v1,v2});
	}
	
	@Test
	public void testVoyage() {
		Voyage v = new Voyage();
		assertNotNull(v);
		assertEquals(0, v.getId());
	}

	@Test
	public void testVoyageStringString() {
		Voyage v = new Voyage(region, description);
		assertNotNull(v);
		assertEquals(0, v.getId());
		assertEquals(region, v.getRegion());
		assertEquals(description, v.getDescriptif());
	}

	@Test
	public void testVoyageStringStringDatesVoyage() {
		Voyage v = new Voyage(region, description,dv);
		assertNotNull(v);
		assertEquals(0, v.getId());
		assertEquals(region, v.getRegion());
		assertEquals(description, v.getDescriptif());
		assertEquals(dv, v.getDatesVoyage());
	}

	@Test
	public void testVoyageStringStringDatesVoyageListOfVoyageur() {
		Voyage v = new Voyage(region, description,dv,voyageurs);
		assertNotNull(v);
		assertEquals(0, v.getId());
		assertEquals(region, v.getRegion());
		assertEquals(description, v.getDescriptif());
		assertEquals(dv, v.getDatesVoyage());
		assertEquals(voyageurs, v.getVoyageurs());
	}

	@Test
	public void testAddVoyageur() {
		Voyage v = new Voyage();
		v.addVoyageur(v1);
		assertEquals(1, v.getVoyageurs().size());
		v.addVoyageur(v2);
		assertEquals(2, v.getVoyageurs().size());
		assertEquals(v1, v.getVoyageurs().get(0));
		assertEquals(v2, v.getVoyageurs().get(1));
	}

	@Test
	public void testSetGetId() {
		Voyage v = new Voyage();
		v.setId(id);
		assertEquals(id, v.getId());
	}

	@Test
	public void testSetGetRegion() {
		Voyage v = new Voyage();
		v.setRegion(region);
		assertEquals(region,v.getRegion());
	}

	@Test
	public void testSetGetDescriptif() {
		Voyage v = new Voyage();
		v.setDescriptif(description);
		assertEquals(description,v.getDescriptif());
	}

	@Test
	public void testSetGetVoyageurs() {
		Voyage v = new Voyage();
		v.setVoyageurs(voyageurs);
		assertEquals(voyageurs,v.getVoyageurs());
	}

	@Test
	public void testSetGetDatesVoyage() {
		Voyage v = new Voyage();
		v.setDatesVoyage(dv);
		assertEquals(dv,v.getDatesVoyage());
	}
	
	@Test
	public void testGetPrixHT() {
		Voyage v = new Voyage();
		DatesVoyage dv = new DatesVoyage();
		dv.setPrixHT(150);
		v.setDatesVoyage(dv);
		v.setVoyageurs(voyageurs);
		assertEquals(150*voyageurs.size(), v.getPrixHT(),0.0);
		
	}

}
