package fr.gtm.bovoyages.dao.mock;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import fr.gtm.bovoyages.dao.VoyageDAO;
import fr.gtm.bovoyages.entities.Voyage;

public class VoyageMockDAO implements VoyageDAO {
	private static long idCompteur = 1;
	private List<Voyage> voyages = new ArrayList<>();

	@Override
	public Voyage save(Voyage voyage) {
		voyage.setId(idCompteur++);
		voyages.add(voyage);
		return voyage;
	}

	@Override
	public void delete(Voyage voyage) {
		Iterator<Voyage> it = voyages.iterator();
		while(it.hasNext()) {
			Voyage v = it.next();
			if(v.getId() == voyage.getId()) {
				it.remove();
				return;
			}
		}

	}

	@Override
	public void upddate(Voyage voyage) {
		for(Voyage v : voyages) {
			if(v.getId() == voyage.getId()) {
				v = voyage;
				return;
			}
		}

	}

	@Override
	public Voyage getDatesVoyageById(long id) {
		for(Voyage v : voyages) {
			if(v.getId() == id) {
				return v;
			}
		}
		return null;
	}

}
