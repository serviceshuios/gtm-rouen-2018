package fr.gtm.bovoyages.dao.mock;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import fr.gtm.bovoyages.dao.DestinationDAO;
import fr.gtm.bovoyages.entities.DatesVoyage;
import fr.gtm.bovoyages.entities.Destination;

public class DestinationMockDAO implements DestinationDAO {
	private static long idCompteur = 1;
	private List<Destination> destinations = new ArrayList<>();

	@Override
	public Destination save(Destination destination) {
		destination.setId(idCompteur++);
		destinations.add(destination);
		return destination;
	}

	@Override
	public void delete(Destination destination) {
		Iterator<Destination> it = destinations.iterator();
		while(it.hasNext()) {
			Destination d = it.next();
			if(d.getId() == destination.getId()) {
				it.remove();
				return;
			}
		}

	}

	@Override
	public void update(Destination destination) {
		Iterator<Destination> it = destinations.iterator();
		while(it.hasNext()) {
			Destination d = it.next();
			if(d.getId() == destination.getId()) {
				d = destination;
				return;
			}
		}

	}

	@Override
	public List<Destination> getDestinationsByRegion(String region) {
		List<Destination> dest = new ArrayList<>();
		for(Destination d : destinations) {
			if(d.getRegion().equals(region)) {
				dest.add(d);
			}
		}
		return dest;
	}

	@Override
	public Destination getDestinationById(long id) {
		for(Destination d : destinations) {
			if(d.getId() == id) {
				return d;
			}
		}	
		return null;
	}

	@Override
	public List<DatesVoyage> getDatesVoyages(Destination destination) {
		for(Destination d : destinations) {
			if(d.getId() == destination.getId()) {
				return d.getDatesVoyages();
			}
		}	
		return null;
	}

	@Override
	public List<Destination> getAllDestinations() {
		return destinations;
	}

}
