package fr.gtm.bovoyages.dao;

import fr.gtm.bovoyages.entities.Voyage;

/**
 * Interface DAO<br>
 * Contient l'ensemble des méthodes permettant la gestion des enregistrements pour un voyage
 */
public interface VoyageDAO {
	Voyage save(Voyage voyage);
	void delete(Voyage voyage);
	void upddate(Voyage voyage);
	Voyage getDatesVoyageById(long id);
}
