package fr.gtm.projet;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.Test;
/**
 * 
 * @author Class VoyageurTest qui test les voyageurs avec J Unit
 * 
 */
public class VoyageurTest {
	Date dateNaissance = new Date(01 / 01 / 1970);
	Voyageur v1 = new Voyageur("M", "BOB", "José", dateNaissance);

	@Test
	public void testGetCivilite() {
		String civiliteClient = "M";
		assertEquals(civiliteClient, v1.getCivilite());
	}

	@Test
	public void testSetCivilite() {
		v1.setCivilite("Mme");
		assertEquals(v1.getCivilite(), "Mme");

	}

	@Test
	public void testGetNom() {
		String nomClient = "BOB";
		assertEquals(nomClient, v1.getNom());
	}

	@Test
	public void testSetNom() {
		v1.setNom("BOBI");
		assertEquals(v1.getNom(), "BOBI");
	}

	@Test
	public void testGetPrenom() {
		String prenomClient = "José";
		assertEquals(prenomClient, v1.getPrenom());
	}

	@Test
	public void testSetPrenom() {
		v1.setPrenom("Josette");
		assertEquals(v1.getPrenom(), "Josette");
	}

	@Test
	public void testGetDateNaissance() {
		Date naissanceClient = new Date(01 / 01 / 1970);
		assertEquals(naissanceClient, v1.getDateNaissance());
	}

	@Test
	public void testSetDateNaissance() {
		v1.setDateNaissance(new Date(02 / 02 / 1970));
		assertEquals(v1.getDateNaissance(), new Date(02 / 02 / 1970));
	}

}
