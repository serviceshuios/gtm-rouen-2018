package fr.gtm.projet;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
/**
 * 
 * @author Class DestinationMockDAOTest qui test les destinations avec J Unit
 * 
 */
public class DestinationMockDAOTest {

	Destination destination = new Destination();
	List<Destination> destinations = destination.getAllDestination();

	Destination d1 = new Destination("France", "Visite Paris", "France_1.jpeg");
	Destination d2 = new Destination("France", "Visite Rouen", "France_2.jpeg");
	Destination d3 = new Destination("Japon", "Visite Tokyo", "Japon_1.jpeg");

	
	
	@Test
	public void testCreate() {
		assertTrue(destinations.add(d1));
	}

	@Test
	public void testDelete() {
		destinations.add(d1);

		assertTrue(destinations.remove(d1));
	}

	@Test
	// Comme updtate n'utilise que du create et du delete pas besoin de tester
	public void testUpdate() {
		destinations.add(d1);
		Destination d1_update = new Destination("France", "Visite de la ville de Paris", "France_1.jpeg");
		
		assertTrue(destinations.remove(d1));
		assertTrue(destinations.add(d1_update));
	}

	@Test
	public void testGetDesinationByRegion() {
		String region = "France" ;
		destinations.add(d1);
		destinations.add(d3);
		
		assertEquals(d1.getRegion(),region);
		assertNotSame(d3.getRegion(),region);
	}
		  

	 @Test 
	 public void testGetDestinationByID() { 
	//	 fail("Not yet implemented"); 
	 }
	 
	 @Test 
	 public void testGetDatesVoyages() { 
	//	 fail("Not yet implemented"); 
	 }

	
	  @Test
	  public void testGetAllDestination() {
		  assertNotNull(destinations);
	  }
	 
}
