package fr.gtm.projet;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
/**
 * 
 * @author Class VoyageMockDAOTest qui test les voyages avec J Unit
 * 
 */
public class VoyageMockDAOTest {
	Voyage voyage = new Voyage();
	List<Voyage> voyages = voyage.getAllVoyage() ;
	
	Voyage v1 = new Voyage("France", "Visite Paris");
	
	@Test
	public void testCreate() {
		assertTrue(voyages.add(v1));
	}

	@Test
	public void testDelete() {
		voyages.add(v1);

		assertTrue(voyages.remove(v1));
	}

	@Test
	public void testUpdate() {
		voyages.add(v1);
		Voyage v1_update = new Voyage("France", "Visite de la ville de Paris");
		
		assertTrue(voyages.remove(v1));
		assertTrue(voyages.add(v1_update));
	}

	@Test
	public void testGetVoyageByID() {
		//fail("Not yet implemented");
	}

}
