package fr.gtm.projet;

import static org.junit.Assert.*;

import org.junit.Test;
/**
 * 
 * @author Class ClientTest qui test les clients avec J Unit
 * 
 */
public class ClientTest {
	Client c1 = new Client("Toto");
	
	@Test
	public void testGetNom() {
		String nomClient = "Toto" ;
		assertEquals(nomClient, c1.getNom());
	}

	@Test
	public void testSetNom() {
	c1.setNom("Tata");
	assertEquals(c1.getNom(),"Tata");
	}

}
