package fr.gtm.projet;

//import static org.junit.Assert.*;

//import org.junit.Test;
/**
 * 
 * @author Class VoyageTest qui test les voyages  avec J Unit
 * 
 */
public class VoyageTest {

// Pas de test voyage car test déja réalisé sur Client, Voyageur et DateVoyage

}
