package fr.gtm.projet;

import java.util.ArrayList;
import java.util.List;
/**
 * 
 * @author Class Voyage qui gere les voyages
 * 
 */
public class Voyage {

	private long id = 0;
	private Client client;
	private Voyageur voyageur;
	private DatesVoyage dateVoyage;
	private String region;
	private String descriptif;

	private List<Voyageur> voyageurs = new ArrayList<>();
	private List<Client> clients = new ArrayList<>();
	private List<Voyage> voyages = new ArrayList<>();

	public Voyage(String region, String descriptif) {
		super();
		this.region = region;
		this.descriptif = descriptif;
	}

	public Voyage() {
		super();
	}

	public Client getClient() {
		return client;
	}

	public void setClient(Client client) {
		this.client = client;
	}

	public Voyageur getVoyageur() {
		return voyageur;
	}

	public void setVoyageur(Voyageur voyageur) {
		this.voyageur = voyageur;
	}

	public DatesVoyage getDateVoyage() {
		return dateVoyage;
	}

	public void setDateVoyage(DatesVoyage dateVoyage) {
		this.dateVoyage = dateVoyage;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getDescriptif() {
		return descriptif;
	}

	public void setDescriptif(String descriptif) {
		this.descriptif = descriptif;
	}

	public Destination getDestination() {
		return destination;
	}

	public void setDestination(Destination destination) {
		this.destination = destination;
	}

	private Destination destination = new Destination();

	public void creerListeClient() {

	}

	public void add(Voyageur voyageur) {
		voyageurs.add(voyageur);
	}

	public void remove(Voyageur voyageur) {
		voyageurs.remove(voyageur);
	}

	public List<Voyageur> getAllVoyageurs() {
		return voyageurs;
	}

	public void add(Client client) {
		clients.add(client);
	}

	public List<Client> getAllClients() {
		return clients;
	}

	public double getPrixTotalHt(int nbVoyageur) {
		double prixTotal = dateVoyage.getTarifUnitaireHT() * nbVoyageur;
		return prixTotal;
	}

	public List<Voyage> getAllVoyage() {
		return voyages;
	}
}
