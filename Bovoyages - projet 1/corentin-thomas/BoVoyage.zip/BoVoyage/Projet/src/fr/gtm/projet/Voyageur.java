package fr.gtm.projet;

import java.util.Date;
/**
 * 
 * @author Class Voyageur qui gere les voyageurs
 * 
 */
public class Voyageur {

	private String civilite;
	private String nom;
	private String prenom;

	private long id = 0;
	private Date dateNaissance = new Date();

	public Voyageur(String civilite, String nom, String prenom, Date dateNaissance) {
		super();
		this.civilite = civilite;
		this.nom = nom;
		this.prenom = prenom;
		this.dateNaissance = dateNaissance;
	}

	public String getCivilite() {
		return civilite;
	}

	public void setCivilite(String civilite) {
		this.civilite = civilite;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public Date getDateNaissance() {
		return dateNaissance;
	}

	public void setDateNaissance(Date dateNaissance) {
		this.dateNaissance = dateNaissance;
	}

}
