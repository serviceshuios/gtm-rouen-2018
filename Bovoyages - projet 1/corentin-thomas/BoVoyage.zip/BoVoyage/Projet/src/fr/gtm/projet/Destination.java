package fr.gtm.projet;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author Class Destination qui gere les destinations
 * 
 */

public class Destination {

	private String Region;
	private String Descriptif;
	private String Image;
	private long id = 0 ;

	private List<Destination> destinations = new ArrayList<>();
	
	public Destination(String region, String descriptif, String image) {
		super();
		Region = region;
		Descriptif = descriptif;
		Image = image;
	}

	public Destination() {
		super();

	}

	public String getRegion() {
		return Region;
	}

	public void setRegion(String region) {
		Region = region;
	}

	public String getDescriptif() {
		return Descriptif;
	}

	public void setDescriptif(String descriptif) {
		Descriptif = descriptif;
	}

	public String getImage() {
		return Image;
	}

	public void setImage(String image) {
		Image = image;
	}

	public List<Destination> getAllDestination() {
		return destinations;
	}
	
	public List<Destination> getDesinationByRegion(String region) {
		return destinations ;
	}

}
