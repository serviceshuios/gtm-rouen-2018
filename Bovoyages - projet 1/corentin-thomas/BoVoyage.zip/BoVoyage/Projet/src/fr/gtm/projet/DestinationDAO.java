package fr.gtm.projet;

import java.util.List;
/**
 * 
 * @author Class DestinationDAO
 * 
 */
public interface DestinationDAO {

	public void create(Destination d);

	public void delete(Destination d);

	public void update(Destination d);

	public List<Destination> getDesinationByRegion(String region);

	public Destination getDestinationByID(long id);

	public List<DatesVoyage> getDatesVoyages(Destination d);

	public List<Destination> getAllDestination();

}
