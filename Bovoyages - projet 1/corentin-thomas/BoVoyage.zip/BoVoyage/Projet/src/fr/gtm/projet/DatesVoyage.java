package fr.gtm.projet;

import java.util.Date;
/**
 * 
 * @author Class Date de voyage gere les dates de voyage pour les destinations
 * 
 */
public class DatesVoyage {

	private Date dateAller = new Date();
	private Date dateRetour = new Date();
	private double tarifUnitaireHT;
	private long id = 0;

	public DatesVoyage(Date dateAller, Date dateRetour, double tarifUnitaireHT) {
		super();
		this.dateAller = dateAller;
		this.dateRetour = dateRetour;
		this.tarifUnitaireHT = tarifUnitaireHT;
	}

	public Date getDateAller() {
		return dateAller;
	}

	public void setDateAller(Date dateAller) {
		this.dateAller = dateAller;
	}

	public Date getDateRetour() {
		return dateRetour;
	}

	public void setDateRetour(Date dateRetour) {
		this.dateRetour = dateRetour;
	}

	public double getTarifUnitaireHT() {
		return tarifUnitaireHT;
	}

	public void setTarifUnitaireHT(double tarifUnitaireHT) {
		this.tarifUnitaireHT = tarifUnitaireHT;
	}

}
