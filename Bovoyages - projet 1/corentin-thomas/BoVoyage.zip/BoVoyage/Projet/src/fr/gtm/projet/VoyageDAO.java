package fr.gtm.projet;

import java.util.List;
/**
 * 
 * @author Class VoyageDAO 
 * 
 */
public interface VoyageDAO {

	public void create(Voyage v);

	public void delete(Voyage v);

	public void update(Voyage v);
	
	public Voyage getVoyageByID(long id);

	List<Voyage> getAllVoyage();
	
}
