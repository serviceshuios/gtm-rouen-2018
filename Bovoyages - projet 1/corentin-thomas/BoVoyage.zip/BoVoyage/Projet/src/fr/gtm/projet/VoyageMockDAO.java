package fr.gtm.projet;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author Class VoyageMockDAO qui possede le corps des methodes de Voyage
 * 
 */
public class VoyageMockDAO implements VoyageDAO {
	List<Voyage> voyages = new ArrayList<Voyage>();
	
	@Override
	public void create(Voyage v) {
		voyages.add(v);
	}

	@Override
	public void delete(Voyage v) {
		voyages.remove(v);

	}

	@Override
	public void update(Voyage v) {
		voyages.remove(v);
		voyages.add(v);
	}

	@Override
	public Voyage getVoyageByID(long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Voyage> getAllVoyage() {
		return voyages;
	}

}
