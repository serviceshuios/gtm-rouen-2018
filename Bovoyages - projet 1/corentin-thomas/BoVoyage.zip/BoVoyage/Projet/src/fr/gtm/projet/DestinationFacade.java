package fr.gtm.projet;
/**
 * 
 * @author Class DestinationFacade
 * 
 */
public class DestinationFacade {
	
	
}
