package fr.gtm.projet;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author Class DestinationMockDAO qui possede le corps des methodes de Destination
 * 
 */

public class DestinationMockDAO implements DestinationDAO {
	List<Destination> destinations = new ArrayList<Destination>();

	@Override
	public void create(Destination d) {
		destinations.add(d);
	}

	@Override
	public void delete(Destination d) {
		destinations.remove(d);
	}

	@Override
	public void update(Destination d) {
		destinations.remove(d);
		destinations.add(d);

	}

	@Override
	public List<Destination> getDesinationByRegion(String region) {
		List<Destination> destinations = new ArrayList<Destination>();
		for (Destination d : this.destinations)
			if (d.getRegion().equals(region)) {
				destinations.add(d);
			}
		return destinations;
	}

	@Override
	public Destination getDestinationByID(long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<DatesVoyage> getDatesVoyages(Destination d) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Destination> getAllDestination() {
		return destinations;
	}

}
