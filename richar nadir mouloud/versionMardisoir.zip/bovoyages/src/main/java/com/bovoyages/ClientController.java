package com.bovoyages;

public class ClientController {

}
