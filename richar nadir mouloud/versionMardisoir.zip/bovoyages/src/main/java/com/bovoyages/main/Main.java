package com.bovoyages.main;

public class Main {
	/*public static void main(String[] args) throws ParseException {
		//charger le conteneur spring /xml
		
				ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("spring-data.xml");
	 //R�cup�rer les beans
				
				DatesVoyage dat1=context.getBean("datesVoyage", DatesVoyage.class);
				Destination dest1=context.getBean("destination", Destination.class);
				
				DateFormat dateFormat = new SimpleDateFormat("YYYY-MM-dd");
				dat1.setDateAller(dateFormat.parse("2019-06-12"));
				dat1.setDateRetour(dateFormat.parse("2019-06-24"));
				dat1.setPrixHT(359);
				
				IDatesVoyageService serviceDate= context.getBean("serviceDate", ImpDatesVoyageService.class);
				serviceDate.save(dat1);				
				dest1.addDatesVoyage(dat1);
				dest1.setDescription(description);
				dest1.setIdcity(idcity);
				
				IDestinationService serviceDest= context.getBean("serviceDest", ImpDestinationService.class);
				
	}*/
}
