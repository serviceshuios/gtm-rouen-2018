package com.bovoyages;

public class VoyageController {

}
