package com.bovoyages;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.bovoyages.metier.DatesVoyage;
import com.bovoyages.metier.Destination;
import com.bovoyages.service.IDatesVoyageService;
import com.bovoyages.service.IDestinationService;

@Controller
public class AdminController {
	private static final Logger logger = LoggerFactory.getLogger(AdminController.class);

	@Autowired
	private IDestinationService serviceDest;
	@Autowired
	private IDatesVoyageService serviceDate;
	
	@RequestMapping(value="/admin", method = RequestMethod.GET)
	public String main(Model model) {
		model.addAttribute("destinations", serviceDest.getAllDestinations());
		return "admin/admin_view_all_destinations";
	}
	
	@RequestMapping(value = "/editDestination")
	public String editDestination(@RequestParam("idDest") int id, Model model) {
		model.addAttribute("title", "Modifier");
		model.addAttribute("destination", serviceDest.getDestinationById(id));
		model.addAttribute("destinations", serviceDest.getAllDestinations());
		return "admin/admin_destination_form";
	}
	
	@RequestMapping(value = "/addDestination")
	public String addDestination(Model model) {
		model.addAttribute("title", "Ajouter");
		model.addAttribute("destination", new Destination());
		
		return "admin/admin_destination_form";
	}
	
	@RequestMapping(value = "/saveDestination")
	// Model à la fin
	public String saveDestination(@Valid Destination destination, BindingResult bindingResult, Model model) {
		
		if (bindingResult.hasErrors()) {
			model.addAttribute("destinations", serviceDest.getAllDestinations());
			return "admin/admin_view_all_destinations";
		} else {
			serviceDest.save(destination);
			
			model.addAttribute("destinations", serviceDest.getAllDestinations());
			return "admin/admin_view_all_destinations";
		}
	}
	
	@RequestMapping(value = "/deleteDestination")
	public String deleteDestination(@RequestParam("idDest") long id, Model model) {
		serviceDest.delete(id);
		model.addAttribute("destination", new Destination());
		model.addAttribute("destinations", serviceDest.getAllDestinations());
		return "admin/admin_view_all_destinations";
	}
	
	@RequestMapping(value = "/addDateDeVoyage")
	public String addDateDeVoyage(@ModelAttribute("dateVoyage") DatesVoyage dates,@RequestParam("idd") long idDest,@RequestParam("idv")long idDate, Model model) {
		logger.info("<<<<<<<<<<<< datesvoyage destination"+idDest);
		Destination destination = serviceDest.getDestinationById(idDest);
		model.addAttribute("destination", destination);		
		model.addAttribute("dateVoyage", new DatesVoyage());
		Destination dest= new Destination();
		dest.addDatesVoyage(dates);
		model.addAttribute("destinations", serviceDest.getAllDestinations());
		
		return "admin/admin_date_form";
	}
	public String deleteDate(@RequestParam("idv") long idDate, Model model) {
		serviceDate.delete(idDate);
		return "admin/admin_date_form";
	}
	public String addImages(@RequestParam("idDest") long idDest, Model model) {
		
		
		return "admin/admin_image_form";
	}
}
