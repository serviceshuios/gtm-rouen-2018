package com.bovoyages;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.bovoyages.metier.Client;
import com.bovoyages.metier.DatesVoyage;
import com.bovoyages.metier.Destination;
import com.bovoyages.metier.Voyage;
import com.bovoyages.metier.Voyageur;
import com.bovoyages.service.IDatesVoyageService;
import com.bovoyages.service.IDestinationService;
import com.bovoyages.service.IVoyageService;

import java.sql.Date;
import java.util.ArrayList;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Controller
public class DestinationController {
	private static final Logger logger = LoggerFactory.getLogger(DestinationController.class);

	@Autowired
	private IDestinationService serviceDest;

	@Autowired
	private IDatesVoyageService serviceDate;

	@Autowired
	private IVoyageService serviceVoy;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String index(Model model) {
		model.addAttribute("destinations", serviceDest.getAllDestinations());
		return "frontClient/show_all_destinations";
	}

	@RequestMapping(value = "/detailDestination", method = RequestMethod.GET)
	public String detailDestination(@RequestParam long id, Model model) {
		model.addAttribute("destination", serviceDest.getDestinationById(id));
		return "frontClient/show_detail_destinations";
	}

	@RequestMapping(value = "/showCommande")
	public String showCommande(@RequestParam("idDest") long idDest, @RequestParam("idDate") long idDate,
			ModelMap model) {
		Destination destination = serviceDest.getDestinationById(idDest);
		model.addAttribute("destination", destination);
		model.addAttribute("datesVoyage", serviceDate.getDatesVoyageById(destination.getId()));
		return "frontClient/show_commande";
	}

	@RequestMapping(value = "/recapitulatifCommande")
	public String recapitulatifCommande(@RequestParam("idDest") long idDest,
			@RequestParam("idDate") long idDate, @RequestParam("nbVoyageurs") int nbVoyageurs,@RequestParam("prixTot")int prixTot, HttpServletRequest request, HttpServletResponse response,  ModelMap model) {
		
		Voyage voyage = new Voyage();
		
		for(int i=1; i<=nbVoyageurs; i++ ) {
			String civilite=request.getParameter("civilite" +i);
			String nom=request.getParameter("nom" +i);
			String prenom=request.getParameter("prenom" +i);
			String dateDeNaissanceStr=request.getParameter("dateDeNaissance" +i);
			Date dateDeNaissance =	Date.valueOf(dateDeNaissanceStr);
			Voyageur voyageurs = new Voyageur(civilite, nom, prenom, dateDeNaissance);
			
			voyage.addVoyageur(voyageurs);
			
		}

		
		model.addAttribute("client", new Client());
		Destination destination = serviceDest.getDestinationById(idDest);
		DatesVoyage datesVoyage = serviceDate.getDatesVoyageById(idDate);

		model.addAttribute("destination", destination);
		model.addAttribute("datesVoyage", datesVoyage);
		model.addAttribute("prixTot", prixTot);
		model.addAttribute("nbVoyageurs", nbVoyageurs);

		model.addAttribute("voyage", voyage);

		return "frontClient/show_recapitulatif";
	}

}
