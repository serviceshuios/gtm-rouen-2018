function calculer() {

	var nb = document.getElementById("nbVoyageurs").value;
	var prix = document.getElementById("prix").value;
	var prixTot = document.getElementById("prixTot");
	var nb = parseInt(nb);
	var prix = parseInt(prix);

	var prixTotTtc = 1.2 * nb * prix;
	prixTot.value = prixTotTtc;
}

function afficherForm() {
	
	let idDest = document.getElementById("idDest").value;
	let idDate = document.getElementById("idDate").value;
	let nbVoyageurs = document.getElementById("nbVoyageurs").value;
	let prixTot = document.getElementById("prixTot").value;
	let container = document.getElementById("inrlog");
	
	let html = "<section id='voyageurs' name='voyageurs'></section><form action='recapitulatifCommande?idDest="+idDest+"&idDate="+idDate+"&prixTot="+prixTot+"&nbVoyageurs="+nbVoyageurs+"' method='post'>";
	
	html += "<div id='servicewrap'><div class='container'><h1>FORMULAIRE DE SAISIE DES VOYAGEURS</h1><p><div class='input-group input-group-sm mb-3'><span class='input-group-addon'>Cli.</span><input type='text' class='form-control' name='nomClient' id='nomClient' placeholder='Nom du Client' aria-label='Small' aria-describedby='inputGroup-sizing-sm'></div></p><div class='row mt'>";
	
	for(let i=1; i<=nbVoyageurs; i++) {
		html +="<div class='col-lg-3 voyageurs'>"+i+"<p><div class='input-group input-group-sm mb-3'><span class='input-group-addon'>Civ.</span><input type='text' class='form-control' name='civilite"+i+"' id='civilite"+i+"' placeholder='Civilité' aria-label='Small' aria-describedby='inputGroup-sizing-sm'></div></p>"+
			"<p><div class='input-group input-group-sm mb-3'><span class='input-group-addon'>Nom.</span><input type='text' class='form-control' name='nom"+i+"' id='nom"+i+"' placeholder='Nom' aria-label='Small' aria-describedby='inputGroup-sizing-sm'></div></p>"+
			"<p><div class='input-group input-group-sm mb-3'><span class='input-group-addon'>Pré.</span><input type='text' class='form-control' name='prenom"+i+"' id='prenom"+i+"' placeholder='Prénom' aria-label='Small' aria-describedby='inputGroup-sizing-sm'></div></p>"+
			"<p><div class='input-group input-group-sm mb-3'><span class='input-group-addon'>Dat.</span><input type='date'class='form-control' name='dateDeNaissance"+i+"' id='dateDeNaissance"+i+"'aria-label='Small' aria-describedby='inputGroup-sizing-sm'></div></div></p>";
	}
	html +="</div><br>" +
			"<button type='submit' class='btn btn-primary btn-sm'id='CommandeBtn'><i class='fa fa-star'></i>&nbsp;Commander</button></div></div></form>";
	

	container.innerHTML= html;
}

	



