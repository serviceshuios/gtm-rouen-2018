package com.bovoyages;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.bovoyages.metier.Client;
import com.bovoyages.metier.Destination;
import com.bovoyages.metier.Voyageur;
import com.bovoyages.service.IDatesVoyageService;
import com.bovoyages.service.IDestinationService;
import com.bovoyages.service.IVoyageService;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
@Controller
public class DestinationController {
	private static final Logger logger = LoggerFactory.getLogger(DestinationController.class);
	
	@Autowired
	private IDestinationService serviceDest;
	
	@Autowired
	private IDatesVoyageService serviceDate;
	
	@Autowired
	private IVoyageService serviceVoy;
	
	@RequestMapping(value="/", method = RequestMethod.GET)
	public String index(Model model) {
		//model.addAttribute("destination",new Destination());
		model.addAttribute("destinations",serviceDest.getAllDestinations());
		return "frontClient/show_all_destinations";
	}
	
	@RequestMapping(value="/detailDestination", method = RequestMethod.GET)
	public String detailDestination(@RequestParam long id, Model model) {
		logger.info("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< idestination "  + id);		
		//Destination destination =serviceDest.getDestinationById(id);
		model.addAttribute("destination",serviceDest.getDestinationById(id));
		//model.addAttribute("datesVoyages",serviceDate.getDatesVoyageById(destination.getId()));
		return "frontClient/show_detail_destinations";
	}
	
	@RequestMapping(value="/showCommande")	
	public String showCommande(@RequestParam("id") long id,@RequestParam("idDate") long idDate,ModelMap model) {

		logger.info("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< idestination rrrr "  + id);	
		logger.info("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< idestination rrrroooooo "  + idDate);	
		Destination destination =serviceDest.getDestinationById(id);
		model.addAttribute("destination",destination);
		model.addAttribute("datesVoyage",serviceDate.getDatesVoyageById(destination.getId()));
		return "frontClient/index";
	}
	
	@RequestMapping(value="/recapitulatifCommande")	
	public String recapitulatifCommande(Client client,long idDest,long idDate,										
										BindingResult bindingResult,
										ModelMap model) {
		if (bindingResult.hasErrors()) {
			model.addAttribute("destinations",serviceDest.getAllDestinations());
			return "frontClient/show_all_destinations";
		}
		
		/*List<Voyageur> voy = new ArrayList<>();
		for (Voyageur voyageur : voyageurs) {
			voy.add(voyageur);
		}*/
	
		model.addAttribute("client", new Client());
		
		
		//model.addAttribute("voyageurs",new Voyageur());
		
		logger.info("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< recap " );
		model.addAttribute("client", new Client());
		
		return "frontClient/index";
	}
	
}
