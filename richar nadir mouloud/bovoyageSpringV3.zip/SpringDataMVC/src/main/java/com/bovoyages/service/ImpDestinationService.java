package com.bovoyages.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bovoyages.dao.IDestinationRepository;
import com.bovoyages.metier.Destination;

@Service("serviceDestination")
public class ImpDestinationService implements IDestinationService {

	@Autowired
	private IDestinationRepository daoDestiantion;
	@Override
	public void save(Destination d) {		
		daoDestiantion.save(d);
	}

	@Override
	public void update(Destination d) {
		daoDestiantion.save(d);

	}

	@Override
	public void delete(long id) {
		if(id != 0) {
			Destination destination=this.getDestinationById(id);
			if (destination.getEtat() == true) {
				destination.setEtat(false);
				daoDestiantion.save(destination);
			}			
		}
	}

	@Override
	public List<Destination> getAllDestinationsWithNull() {
		
		return daoDestiantion.findAll();
	}

	@Override
	public Destination getDestinationById(long id) {
		
		return daoDestiantion.findDestinationByEtatTrueAndId(id);
	}
	
	public List<Destination> getAllDestinations(){
		return daoDestiantion.findDestinationByEtatTrue();				
	}
		
		
	

}
