package org.antislashn.security.service;

import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Service;

@Service
public class CalculService {
	
	@Secured("ROLE_COMPTA")
	public double calcul(){
		return 10.0;
	}
}
