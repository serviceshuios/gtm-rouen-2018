package org.antislashn.security;

import java.security.Principal;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import org.antislashn.security.service.CalculService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	@Autowired private CalculService calculService;
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info(">>>> PUBLIC");		
		return "home";
	}
	
	@RequestMapping(value = "/test", method = RequestMethod.GET)
	public String testTag(Locale locale, Model model) {
		logger.info(">>>> PUBLIC");		
		return "testtag";
	}
	
	@RequestMapping(value="/compta", method = RequestMethod.GET)
	public String goToCompta(Model model){
		logger.info(">>>> COMPTA");
		return "compta/compta";
	}
	@RequestMapping(value="/admin", method = RequestMethod.GET)
	public String goToAdmin(Model model, Principal principal){
		logger.info(">>>> COMPTA");
		//Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		//User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String name = principal.getName();
		logger.info(">>>> name = "+name);
		return "admin/admin";
	}
	
	@RequestMapping(value="/login", method=RequestMethod.GET)
	public String goToLogin(Model model){
		return "login/login";
	}
	
	@RequestMapping(value="/failure", method=RequestMethod.GET)
	public String goToLoginFailure(Model model){
		return "login/failure";
	}
	
	@RequestMapping(value="/calcul", method=RequestMethod.GET)
	public String goToCalcul(Model model){
		double result = calculService.calcul();
		logger.info(">>> RESULT : "+result);
		return "home";
	}
}
