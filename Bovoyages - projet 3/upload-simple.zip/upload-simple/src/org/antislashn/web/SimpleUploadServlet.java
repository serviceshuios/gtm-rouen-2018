package org.antislashn.web;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 * Servlet implementation class SimpleUploadServlet
 */
@WebServlet("/SimpleUploadServlet")
@MultipartConfig(location="/home/franck/tmp")
public class SimpleUploadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final static Logger LOG = Logger.getLogger(SimpleUploadServlet.class.getCanonicalName());

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String folder = getServletContext().getInitParameter("upload-folder");
		
		// getParameter fonctionne en enctype="multipart/form-data" grace à l'annotation @MultipartConfig
		String name = request.getParameter("name");
		LOG.info("Paramètre 'name' == "+name);
		LOG.info("Encoding : "+request.getCharacterEncoding());
		final Part filePart = request.getPart("simple-file");
		final String fileName = getFileName(filePart);
		
		// Depuis Java 7
		// copie le fichier reçu vers son emplacement définitif
		Path path = FileSystems.getDefault().getPath(folder, fileName);
		InputStream in = filePart.getInputStream();
		Files.copy(in, path);
		in.close();
		
		// pour supprimer le fichier temporaire
		filePart.delete();
		
		RequestDispatcher rd = getServletContext().getRequestDispatcher("/index.jsp");
		rd.forward(request, response);
	}


	private String getFileName(Part part) {
		final String partHeader = part.getHeader("content-disposition");
	    LOG.log(Level.INFO, "Part Header = {0}", partHeader);
	    for (String content : part.getHeader("content-disposition").split(";")) {
	        if (content.trim().startsWith("filename")) {
	            return content.substring(
	                    content.indexOf('=') + 1).trim().replace("\"", "");
	        }
	    }
	    return null;
	}

}
