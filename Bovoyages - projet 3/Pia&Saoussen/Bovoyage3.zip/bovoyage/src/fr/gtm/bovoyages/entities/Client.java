package fr.gtm.bovoyages.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * Classe mod�lisant un client<br>
 * Le voyage est pay� par le client<br>
 * Le client peut-�tre une personne ou un organisme.
 * @author franck
 *
 */
@Entity
@Table(name="clients")

public class Client implements Serializable{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="pk")
	private int id;
	private String nom;
	
	public Client() {}
	
	public Client(String nom) {
		this.nom = nom;
	}
	
	@Override
	public String toString() {
		return "Client [id=" + id + ", nom=" + nom + "]";
	}

	/**
	 * ID de synchronisation avec la cl� primaire
	 * @return
	 */
	public int getId() {
		return id;
	}
	/**
	 * ID de synchronisation avec la cl� primaire
	 * <h3>Ne doit pas �tre mis � jour en dehors du DAO</h3>
	 * @param id
	 */
	public void setId(int id) {
		this.id = id;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	
	
}
