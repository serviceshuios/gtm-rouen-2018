package fr.gtm.bovoyages.dto;

import java.io.Serializable;
import java.util.Date;


public class DatesVoyageDTO implements Serializable{
	private int id;
	private Date dateAller;
	private Date dateRetour;
	private double prixHT;
	
	public DatesVoyageDTO() {}

	public DatesVoyageDTO(Date dateAller, Date dateRetour, double prixHT) {
		this.dateAller = dateAller;
		this.dateRetour = dateRetour;
		this.prixHT = prixHT;
	}

	public int getId() {
		return id;
	}
	
	
	public void setId(int id) {
		this.id = id;
	}

	public Date getDateAller() {
		return dateAller;
	}

	public void setDateAller(Date dateAller) {
		this.dateAller = dateAller;
	}

	public Date getDateRetour() {
		return dateRetour;
	}

	public void setDateRetour(Date dateRetour) {
		this.dateRetour = dateRetour;
	}

	public double getPrixHT() {
		return prixHT;
	}

	public void setPrixHT(double prixHT) {
		this.prixHT = prixHT;
	}
	
	

}
