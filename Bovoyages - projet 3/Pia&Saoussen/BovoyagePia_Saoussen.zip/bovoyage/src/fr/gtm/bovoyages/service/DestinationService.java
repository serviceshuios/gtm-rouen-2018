package fr.gtm.bovoyages.service;



import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Singleton;

import javax.ws.rs.GET;

import fr.gtm.bovoyages.dao.DestinationDAO;
import fr.gtm.bovoyages.entities.DatesVoyage;
import fr.gtm.bovoyages.entities.Destination;



@Singleton
public class DestinationService {
	@EJB private DestinationDAO dao;

	
	@GET
	public List<Destination> getAllDestinations(){
		return dao.getAllDestinations();
	}
	
    @GET
	public List<DatesVoyage> getDatesVoyages(Destination destination) {
		return dao.getDatesVoyagesByDestination(destination);
	}
	
	@GET
	public List<Destination> getDestinationsByRegion(String region){
		return dao.getDestinationsByRegion(region);
	}
	
	
	@GET
	public List<DatesVoyage> getDatesVoyageByID(int idD) {
		
		return dao.getDatesVoyageByID(idD);
	}

	
	



}
