package fr.gtm.bovoyages.dao;

import javax.ejb.Local;


import fr.gtm.bovoyages.entities.Voyage;

@Local
public interface VoyageDAO {

	void save(Voyage voyage);
	void delete(Voyage voyage);
	void update(Voyage voyage);
	void saveOrUpdate(Voyage voyage);
	Voyage getDatesVoyageById(int id);
}

