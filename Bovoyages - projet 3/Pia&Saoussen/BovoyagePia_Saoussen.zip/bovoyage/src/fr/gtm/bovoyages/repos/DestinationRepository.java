package fr.gtm.bovoyages.repos;


import java.util.ArrayList;
import java.util.List;

import java.util.logging.Logger;

import javax.ejb.Singleton;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;


import fr.gtm.bovoyages.dao.DestinationDAO;
import fr.gtm.bovoyages.entities.DatesVoyage;
import fr.gtm.bovoyages.entities.Destination;



/**
 * Contient les m�thodes des requ�tes de donn�es; 
 * Instancie la DataSource
 * Utilise 'getConnection'
 */

@Singleton

public class DestinationRepository implements DestinationDAO {
	@PersistenceContext(name="bovoyages") private EntityManager em; 
	
	private static final Logger LOG = Logger.getLogger(DestinationRepository.class.getName());
	
	
	public DestinationRepository() {
		super();
	}


	public List<Destination> getDestinationsByRegion(String region) {
		
		return null;
	}



	public Destination getDestinationById(int id) {

		return em.find(Destination.class, id);
	}

	
	public List<Destination> getAllDestinations() {
		List<Destination> destinations = em.createNamedQuery("allDestinations",Destination.class).getResultList();

		return destinations;
	}
	
	public List<DatesVoyage> getDatesVoyagesByDestination(Destination destination){	
	List<DatesVoyage> datesVoyage = em.createNamedQuery("DatesByDestination",DatesVoyage.class).getResultList();
    return datesVoyage;
	}


	public List<DatesVoyage> getDatesVoyageByID(int idDestination) {
		List<DatesVoyage> datesVoyages = new ArrayList<>();
		Destination destination= em.find(Destination.class, idDestination);
		for(DatesVoyage dv : destination.getDatesVoyages())	{
			datesVoyages.add(dv);
		}
					
	    return datesVoyages;
	}
	public void save(Destination  destination) {
		em.persist(destination);
	}
	
	public void delete(Destination  destination) {
		Destination d1 = em.find(Destination.class, destination.getId());
		em.remove(d1);	
	}
	
	
	public void update(Destination  destination) {
		em.merge(destination);
	}
	
	public void saveOrUpdate(Destination destination) {
		if(destination.getId()==0) {
			save(destination);
		}else {
			update(destination);
		}
	}


	
}
	
	
	
	
	
	
	


		

	