package fr.gtm.bovoyages.dao;

import java.util.List;

import javax.ejb.Local;

import fr.gtm.bovoyages.entities.DatesVoyage;
import fr.gtm.bovoyages.entities.Destination;
import fr.gtm.bovoyages.entities.Voyage;

/**
 * Interface DAO<br>
 * Contient l'ensemble des méthodes permettant la gestion des enregistrements pour une Destination
 */
@Local
public interface DestinationDAO {
//	Destination save(Destination destination);
//	void delete(Destination destination);
//	void update(Destination destination);
	List<Destination> getDestinationsByRegion(String region);
	Destination getDestinationById(int id);
	List<DatesVoyage> getDatesVoyagesByDestination(Destination destination);
	List<Destination> getAllDestinations();
	List<DatesVoyage> getDatesVoyageByID(int idDestination);
	void save(Destination  destination);
	void delete(Destination  destination);
	void update(Destination  destination);
	void saveOrUpdate(Destination destination);
	
}
