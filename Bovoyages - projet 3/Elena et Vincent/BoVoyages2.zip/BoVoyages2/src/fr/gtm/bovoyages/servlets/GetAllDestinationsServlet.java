package fr.gtm.bovoyages.servlets;

import java.io.IOException;
import java.util.List;
import java.util.logging.Logger;

import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import fr.gtm.bovoyages.entities.Destination;
import fr.gtm.bovoyages.facades.DestinationFacade;

/**
 * Servlet permettant l'affichage d'une liste de destinations contenue en base de données via la jsp du même nom.
 */
@WebServlet("/GetAllDestinationsServlet")
public class GetAllDestinationsServlet extends HttpServlet {

	
	private static final Logger LOG = Logger.getLogger(GetAllDestinationsServlet.class.getName());
	private static final long serialVersionUID = 1L;
	
	@EJB private DestinationFacade dFacade;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		List<Destination> destinations = dFacade.getAllDestinations();

		request.setAttribute("destinations", destinations);

		String page = "/get_all_destinations.jsp";

		RequestDispatcher rd = getServletContext().getRequestDispatcher(page);
		rd.forward(request, response);
		
		LOG.info(">>> GetAllDestinationsServlet : Requête envoyée");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
