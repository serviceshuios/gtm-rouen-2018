package fr.gtm.bovoyages.dao;



import javax.ejb.Singleton;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;


import fr.gtm.bovoyages.entities.DatesVoyage;
import fr.gtm.bovoyages.entities.Destination;
@Singleton
public class DatesVoyageDAO {

    @PersistenceContext(name="bovoyages") private EntityManager em;
   
    /**
     * Constructeur de la fa�ade.
     */
    public DatesVoyageDAO() {

    }

    /**
     * M�thode permettant la sauvegarde de dates de voyage en base de donn�es.
     * @param DatesVoyage
     * @return DatesVoyage
     */
    public DatesVoyage save(DatesVoyage datesVoyage) {
        em.persist(datesVoyage);
        return datesVoyage;
    }

    /**
     * M�thode permettant la suppression de dates de voyage en base de donn�es.
     * @param DatesVoyage
     */
    public void delete(DatesVoyage datesVoyage) {
        DatesVoyage dV = em.find(DatesVoyage.class, datesVoyage.getId());
        em.remove(dV);
    }

    /**
     * M�thode permettant la modification de dates de voyage en base de donn�es.
     * @param DatesVoyage
     */
    public void upddate(DatesVoyage datesVoyage) {
        em.merge(datesVoyage);
    }
   
    /**
     * M�thode permettant la r�cup�ration en base de donn�es de dates de voyage en fonction de leur cl� primaire.
     *@param id
     *@return DatesVoyage
     */
    public DatesVoyage getDatesVoyageById(int id) {
        return em.find(DatesVoyage.class, id);
    }

    public Destination getDestinationByDatesVoyage(int id) {
        return em.find(Destination.class, id);
    }
}

