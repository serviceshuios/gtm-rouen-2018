package fr.gtm.bovoyages.servlets;

import java.io.IOException;
import java.util.List;
import java.util.logging.Logger;

import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import fr.gtm.bovoyages.entities.DatesVoyage;
import fr.gtm.bovoyages.entities.Destination;
import fr.gtm.bovoyages.facades.DatesVoyageFacade;
import fr.gtm.bovoyages.facades.DestinationFacade;

/**
 * Servlet implementation class BackDeleteDatesVoyageServlet
 */
@WebServlet("/BackOfficeDeleteDatesVoyageServlet")
public class BackOfficeDeleteDatesVoyageServlet extends HttpServlet {
   
    private static final Logger LOG = Logger.getLogger(BackOfficeDeleteDatesVoyageServlet.class.getName());
    private static final long serialVersionUID = 1L;
   
    @EJB private DatesVoyageFacade dvFacade;
    @EJB private DestinationFacade dFacade;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       
        String idDVStr = request.getParameter("idDV");
       
        LOG.info(">>>> BackOfficeDeleteDatesVoyageServlet idDV : "+idDVStr);
       
        if(idDVStr!=null) {
            try{
                DatesVoyage dv = dvFacade.getDatesVoyageById(idDVStr);
                if(dv!=null) {
                    dvFacade.delete(dv);
                }
            }catch(Exception e) {
                LOG.warning("Problème sur id : "+idDVStr );
            }
        }
       
        String idDStr = request.getParameter("idD");
       
        LOG.info(">>>> BackOfficeDeleteDatesVoyageServlet idD : "+idDStr);
       
        if(idDStr!=null) {
            try{
                Destination d = dFacade.getDestinationById(idDStr);
                if(d!=null) {
                    List<DatesVoyage> datesVoyages = dFacade.getDatesVoyages(d);
                    request.setAttribute("datesVoyages", datesVoyages);
                    request.setAttribute("idD",d.getId());
                    request.setAttribute("destination", d);
                }
            }catch(Exception e) {
                LOG.warning("Problème sur id : "+idDStr );
            }
        }
       
        String page = "/destination_form.jsp";

        RequestDispatcher rd = getServletContext().getRequestDispatcher(page);
        rd.forward(request, response);
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       
        doGet(request, response);
    }

}
