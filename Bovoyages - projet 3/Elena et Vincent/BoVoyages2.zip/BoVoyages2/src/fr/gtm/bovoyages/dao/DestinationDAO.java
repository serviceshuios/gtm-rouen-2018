package fr.gtm.bovoyages.dao;


import java.util.ArrayList;
import java.util.List;

import java.util.logging.Logger;

import javax.annotation.PostConstruct;
import javax.ejb.Singleton;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;
import javax.ws.rs.GET;

import fr.gtm.bovoyages.entities.DatesVoyage;
import fr.gtm.bovoyages.entities.Destination;

@Singleton
public class DestinationDAO {
    private static final Logger LOG = Logger.getLogger(DestinationDAO.class.getName());
   
    @PersistenceContext(name="bovoyages") private EntityManager em;

    /**
     * Constructeur du DAO. N�cessite une connection � la base de donn�es
     * (apport�e ici par la dataSource et le fichier context.xml).
     */
    public DestinationDAO() {
        LOG.info(">>> CONSTRUCTEUR DestinationDAO");
    }

    @PostConstruct public void init() {
        LOG.info(">>> POSTCONSTRUCT DestinationDAO "+em);
    }
    /**
     * M�thode permettant la sauvegarde d'une destination en base de donn�es.
     * @param Destination
     * @return Destination
     */
    public Destination save(Destination destination) {
        em.persist(destination);
        return destination;
    }

    /**
     * M�thode permettant la suppression d'une destination en base de donn�es.
     * @param Destination
     */
    public void delete(Destination destination) {
        Destination d = em.find(Destination.class, destination.getId());
        em.remove(d);
    }

    /**
     * M�thode permettant la modification d'une destination en base de donn�es.
     * @param Destination
     */
    public void update(Destination destination) {
        em.merge(destination);
    }

    /**
     * M�thode permettant la r�cup�ration d'une liste de destination pour une m�me r�gion.
     * @param String
     * @return List<Destination>
     */
    public List<Destination> getDestinationsByRegion(String region) {
        return null;
    }
   
    /**
     * M�thode permettant la r�cup�ration d'une liste de destination pour une m�me r�gion.
     * @param String
     * @return List<Destination>
     */
    public List<Destination> getAllDestinations() {
        List<Destination> destinations = em.createNamedQuery("allDestinations", Destination.class).getResultList();
        return destinations;
    }

    /**
     * M�thode permettant de r�cup�rer une destination en base de donn�es gr�ce � sa cl� primaire.
     * @param long id
     * @return Destination
     */
    public Destination getDestinationById(int id) {
        LOG.info(">>> DestinationDAO getDestinationById ID : "+id);
        return em.find(Destination.class, id);
    }
   
    /**
     * M�thode permettant de r�cup�rer une liste de dates de voyage pour une destination.
     * @param Destination
     * @return List<DatesVoyage>
     */
    public List<DatesVoyage> getDatesVoyages(Destination destination) {
        Destination d = em.find(Destination.class, destination.getId());
        List<DatesVoyage> datesVoyages = new ArrayList<>();
        for(DatesVoyage dV : d.getDatesVoyages()) {
            datesVoyages.add(dV);
        }
        return datesVoyages;
    }

    public List<String> getImagesByDestination(Destination d) {
        d = em.find(Destination.class, d.getId());
        List<String> images = new ArrayList<>();
        for(String img : d.getImages()) {
            images.add(img);
        }
        return images;
    }
}
