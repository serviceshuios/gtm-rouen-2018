package fr.gtm.bovoyages.servlets;

import java.io.IOException;
import java.util.logging.Logger;

import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import fr.gtm.bovoyages.entities.DatesVoyage;
import fr.gtm.bovoyages.entities.Destination;
import fr.gtm.bovoyages.facades.DatesVoyageFacade;
import fr.gtm.bovoyages.facades.DestinationFacade;

/**
 * Servlet permettant l'affichage d'une date de voyage pour une destination et
 * son prix en fonction du nombre de voyageurs, via la jsp du m�me nom.
 */
@WebServlet("/BuyVoyageServlet")
public class BuyVoyageServlet extends HttpServlet {

	private static final Logger LOG = Logger.getLogger(BuyVoyageServlet.class.getName());
	private static final long serialVersionUID = 1L;
	@EJB
	private DatesVoyageFacade dvFacade;
	@EJB
	private DestinationFacade dFacade;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String idStrD = request.getParameter("idD");
		String idStrDV= request.getParameter("idDV");

		LOG.info(">>> pk dates_voyage : " + idStrDV);
		LOG.info(">>> pk destination : " + idStrD);

		String nbVoy = request.getParameter("nb_voyageurs");

		if (nbVoy == null) {
			nbVoy = "1";
		}

		LOG.info(">>> nb de voyageurs : " + nbVoy);

		DatesVoyage dv = dvFacade.getDatesVoyageById(idStrDV);

		Destination d = dFacade.getDestinationById(idStrD);

		int nbV = Integer.parseInt(nbVoy);
		double prix = dv.getPrixHT() * nbV;

		request.setAttribute("prix", prix);
		request.setAttribute("dv", dv);
		request.setAttribute("d", d);

		LOG.info(">>> prix : " + prix);
		LOG.info(">>> dateAller : " + dv.getDateAller());
		LOG.info(">>> Destination : " + d.getRegion());

		String page = "/buy_voyage.jsp";

		RequestDispatcher rd = getServletContext().getRequestDispatcher(page);
		rd.forward(request, response);

		LOG.info(">>> BuyVoyageServlet : Requ�te envoy�e");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
