package fr.gtm.bovoyages.dto;

import java.io.Serializable;

import fr.gtm.bovoyages.entities.Destination;


/**
 * Classe modélisant une destination de voyage<br>
 * Cette classe contient aussi le nom des images utilisées pour les affichages<br>
 * @author franck
 *
 */
public class DestinationDTO implements Serializable {
	private final int id;
	private String region;
	private String description;
	private DatesVoyageDTO dateVoyagePromo;
	private String imageVignette ;
	
	
	
	
	public DestinationDTO(Destination destination) {
		this.id = (int) destination.getId();
		this.region = destination.getRegion();
	}

	public long getId() {
		return id;
	}
	

	
	
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

	
	
	public DatesVoyageDTO getDatePromo() {
		return dateVoyagePromo;
	}

	public void setDatePromo(DatesVoyageDTO datePromo) {
		this.dateVoyagePromo = datePromo;
	}

	public String getImageVignette() {
		return imageVignette;
	}

	public void setImageVignette(String imageVignette) {
		this.imageVignette = imageVignette;
	}

	
	

}
