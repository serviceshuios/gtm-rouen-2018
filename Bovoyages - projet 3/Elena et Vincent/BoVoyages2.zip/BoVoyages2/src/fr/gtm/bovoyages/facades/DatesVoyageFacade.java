package fr.gtm.bovoyages.facades;

import javax.ejb.EJB;
import javax.ejb.Singleton;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import fr.gtm.bovoyages.dao.DatesVoyageDAO;
import fr.gtm.bovoyages.entities.DatesVoyage;
import fr.gtm.bovoyages.entities.Destination;

/**
 * Fa�ade utilis�e par la couche de pr�sentation.<br>
 * Cette fa�ade permet � la couche de pr�sentation de ne pas manipuler
 * les DAO
 *
 */

@Singleton
public class DatesVoyageFacade {

    @EJB private DatesVoyageDAO dao;
   
    /**
     * Constructeur de la fa�ade.
     * N�cessite une connection � la base de donn�es (dataSource apport�e par le context.xml).
     * @param dataSource
     */
    public DatesVoyageFacade() {

    }
   
    /**
     * M�thode permettant l'appel du DAO pour la sauvegarde de dates de voyage en base de donn�es.
     * @param DatesVoyage
     * @return DatesVoyage
     */
    public DatesVoyage save(DatesVoyage datesVoyage) {
        return dao.save(datesVoyage);
    }

    /**
     * M�thode permettant l'appel du DAO pour la suppression de dates de voyage en base de donn�es.
     * @param DatesVoyage
     */
    public void delete(DatesVoyage datesVoyage) {
        dao.delete(datesVoyage);
    }

    /**
     * M�thode permettant l'appel du DAO pour la modification de dates de voyage en base de donn�es.
     * @param DatesVoyage
     */
    public void upddate(DatesVoyage datesVoyage) {
        dao.upddate(datesVoyage);
    }

    /**
     * M�thode permettant l'appel du DAO pour la r�cup�ration de dates de voyage en fonction de la cl� primaire.
     * @param String idStr
     * @return DatesVoyage
     */
    public DatesVoyage getDatesVoyageById(String idStr) {
       
        int id = Integer.parseInt(idStr);
        return dao.getDatesVoyageById(id);
    }

    public Destination getDestinationByDatesVoyage(String idStr) {
        int id = Integer.parseInt(idStr);
        return dao.getDestinationByDatesVoyage(id);
    }

}
