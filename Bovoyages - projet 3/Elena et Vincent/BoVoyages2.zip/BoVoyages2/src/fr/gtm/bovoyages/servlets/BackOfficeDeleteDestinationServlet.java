package fr.gtm.bovoyages.servlets;

import java.io.IOException;
import java.util.List;
import java.util.logging.Logger;

import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import fr.gtm.bovoyages.entities.Destination;
import fr.gtm.bovoyages.facades.DestinationFacade;

/**
 * Servlet implementation class BackDeleteDestinationServlet
 */
@WebServlet("/BackOfficeDeleteDestinationServlet")
public class BackOfficeDeleteDestinationServlet extends HttpServlet {
    private static final Logger LOG = Logger.getLogger(BackOfficeDeleteDestinationServlet.class.getName());
    private static final long serialVersionUID = 1L;
   
    @EJB private DestinationFacade dFacade;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       
        String idStr = request.getParameter("id");
       
        if(idStr!=null) {
            try{
                Destination d = dFacade.getDestinationById(idStr);
                if(d!=null) {
                    dFacade.delete(d);
                }
            }catch(Exception e) {
                LOG.warning("Problème sur id : "+idStr );
            }
        }
       
        List<Destination> destinations = dFacade.getAllDestinations();
        request.setAttribute("destinations", destinations);
       
        String page = "/back_office_all_destinations.jsp";
        RequestDispatcher rd = getServletContext().getRequestDispatcher(page);
        rd.forward(request, response);
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       
        doGet(request, response);
    }

}