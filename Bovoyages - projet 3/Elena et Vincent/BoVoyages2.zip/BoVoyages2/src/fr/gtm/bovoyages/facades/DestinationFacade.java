package fr.gtm.bovoyages.facades;

import java.util.List;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Singleton;

import javax.ws.rs.GET;

import fr.gtm.bovoyages.dao.DestinationDAO;
import fr.gtm.bovoyages.entities.DatesVoyage;
import fr.gtm.bovoyages.entities.Destination;

/**
 * Fa�ade utilis�e par la couche de pr�sentation.<br>
 * Cette fa�ade permet � la couche de pr�sentation de ne pas manipuler
 * les DAO
 * @author franck
 *
 */

@Singleton
public class DestinationFacade {
    @EJB private DestinationDAO dao;
   
    private static final Logger LOG = Logger.getLogger(DestinationFacade.class.getName());

    /**
     * Constructeur de la fa�ade.
     * N�cessite une connection � la base de donn�es (dataSource apport�e par le context.xml).
     * @param dataSource
     */
    public DestinationFacade() {

    }
   
    @PostConstruct public void init() {
        System.out.println("---"+dao);
    }
   
    /**
     * M�thode permettant la sauvegarde d'une destination en base de donn�es.
     * @param Destination
     * @return Destination
     */
    public Destination save(Destination destination) {
        return dao.save(destination);
    }

    /**
     * M�thode permettant la suppression d'une destination en base de donn�es.
     * @param Destination
     */
    public void delete(Destination destination) {
        dao.delete(destination);
    }

    /**
     * M�thode permettant la modification d'une destination en base de donn�es.
     * @param Destination
     */
    public void update(Destination destination) {
        dao.update(destination);
    }
   
    /**
     * M�thode permettant de retourner une liste de toutes les destinations pr�sentes en base de donn�es.
     * @return List<Destination>
     */
    public List<Destination> getAllDestinations(){
        return dao.getAllDestinations();
    }
   
    /**
     * M�thode permettant de récupérer une destination en base de donn�es gr�ce � sa cl� primaire.
     * @param String idStr
     * @return Destination
     */
    public Destination getDestinationById(String idStr) {   
        int id = Integer.parseInt(idStr);
       
       
        Destination d = dao.getDestinationById(id);
        Destination destination = new Destination(d.getRegion(), d.getDescription());
        destination.setId(d.getId());
        destination.setImages(dao.getImagesByDestination(d));
        destination.setDatesVoyages(dao.getDatesVoyages(d));
        return destination;
    }
   
    /**
     * M�thode permettant de r�cup�rer une liste de dates de voyage (sauvegard�es en base de donn�es)
     * en fonction de la destination choisie.
     * @param Destination
     * @return List<DatesVoyage>
     */
    public List<DatesVoyage> getDatesVoyages(Destination destination) {
        return dao.getDatesVoyages(destination);
    }
   
    /**
     * M�thode permettant de r�cup�rer une liste de destinations en base de donn�es en fonction de leur r�gion.
     * @param String region
     * @return List<Destination>
     */
    public List<Destination> getDestinationsByRegion(String region){
        return dao.getDestinationsByRegion(region);
    }
   
    /**
     * M�thode permettant de r�cup�rer une liste de dates de voyage pour une destination gr�ce � sa cl� primaire.
     * @param long id
     * @return List<DatesVoyage>
     */
    public List<DatesVoyage> getDatesVoyages(int idDestination){
        Destination destination = dao.getDestinationById(idDestination);
        return dao.getDatesVoyages(destination);
    }
}

