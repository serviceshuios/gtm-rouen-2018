package fr.gtm.bovoyages.servlets;

import java.io.IOException;
import java.util.List;
import java.util.logging.Logger;

import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import fr.gtm.bovoyages.entities.Destination;
import fr.gtm.bovoyages.facades.DestinationFacade;

/**
 * Servlet implementation class BackAddDestinationServlet
 */
@WebServlet("/BackOfficeAddDestinationServlet")
public class BackOfficeAddDestinationServlet extends HttpServlet {
   
    private static final Logger LOG = Logger.getLogger(BackOfficeAddDestinationServlet.class.getName());
    private static final long serialVersionUID = 1L;

    @EJB private DestinationFacade dFacade;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       
        String region = request.getParameter("region");
       
        LOG.info(">>> BackOfficeAddDestinationServlet region : "+region);
       
        String description = request.getParameter("description");
       
        if(region!=null && !region.isEmpty() && description!=null && !description.isEmpty()) {
            Destination d = new Destination(region, description);
            dFacade.save(d);
            LOG.info(">>> BackOfficeAddDestinationServlet destination region : "+d.getRegion());
        }
       
        List<Destination> destinations = dFacade.getAllDestinations();
        request.setAttribute("destinations", destinations);
       
        String page = "/back_Office_all_destinations.jsp";
        RequestDispatcher rd = getServletContext().getRequestDispatcher(page);
        rd.forward(request, response);
    }


    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        doGet(request, response);
    }

}