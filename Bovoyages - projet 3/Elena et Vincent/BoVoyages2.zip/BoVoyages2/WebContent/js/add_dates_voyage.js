"use strict"

function afficherFormDates() {
   
    let idD = document.getElementById("idD").value;
    console.log(idD);
    let container = document.getElementById("containerAddDates");
   
    let html = "<form action='BackOfficeAddDatesVoyageServlet?idD="+idD+"' id='addDatesVoyage' method='post'>";
   
    html += "<table><tr><th>Départ</th><th>Retour</th><th>Prix TTC</th></tr>" +
            "<tr><td><input type='date' name='newDateAller' id='newDateAller' required='required'></td>" +
            "<td><input type='date' name='newDateRetour' id='newdateRetour' required='required'></td>" +
            "<td><input type='number' name='newPrixHT' id='newPrixHT'/> €</td>" +
            "<td><button type='submit'>Ajouter</button></tr></table></form>";
   
    console.log(html);
    container.innerHTML= html;
}

document.addEventListener("DOMContentLoaded", function() {
        document.getElementById("buttAddDates").addEventListener("click",afficherFormDates);
});