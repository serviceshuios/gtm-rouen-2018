package org.antislashn.web;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collection;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 * Servlet implementation class SimpleUploadServlet
 */
@WebServlet("/MultipleUploadServlet")
@MultipartConfig
public class MultipleUploadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final static Logger LOGGER = Logger.getLogger(MultipleUploadServlet.class.getCanonicalName());

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String folder = getServletContext().getInitParameter("upload-folder");
		
		// getParameter fonctionne en enctype="multipart/form-data" grace à l'annotation @MultipartConfig
		String name = request.getParameter("name");
		LOGGER.info("Paramètre 'name' == "+name);
		
		Collection<Part> parts = request.getParts();
		
		for(Part filePart : parts){
			final String fileName = getFileName(filePart);
			if(fileName == null)
				continue; // le part content n'est pas de type 'filename'
			Path path = FileSystems.getDefault().getPath(folder, fileName);
			if(!path.toFile().exists()){
				InputStream in = filePart.getInputStream();
				Files.copy(in, path);
				in.close();
				filePart.delete();
			}
			else{
				// il faut prévoir un traitement spécifique si le fichier existe déjà
				//		demander l'accord de l'utilisateur
				//		toujours remplacer le fichier
				//		...
				LOGGER.info(">>> Le fichier "+fileName+" existe déjà dans la destination, il ne sera pas recopié");
			}
		}
		
		RequestDispatcher rd = getServletContext().getRequestDispatcher("/index.jsp");
		rd.forward(request, response);
	}


	private String getFileName(Part part) {
		final String partHeader = part.getHeader("content-disposition");
	    LOGGER.log(Level.INFO, "Part Header = {0}", partHeader);
	    for (String content : part.getHeader("content-disposition").split(";")) {
	        if (content.trim().startsWith("filename")) {
	            return content.substring(
	                    content.indexOf('=') + 1).trim().replace("\"", "");
	        }
	    }
	    return null;
	}

}
