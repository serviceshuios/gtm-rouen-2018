package org.bovoyages;

import java.util.List;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.bovoyages.dao.DestinationDAO;
import org.bovoyages.dto.DatesVoyageDTO;
import org.bovoyages.dto.DestinationDTO;
import org.bovoyages.entities.DatesVoyage;
import org.bovoyages.entities.Destination;
import org.bovoyages.services.DestinationsService;

public class MainDestinationDTO {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("bovoyages");
		DestinationsService service = new DestinationsService(emf);
		
		List<DestinationDTO> destinations = service.getAllDestinationDTOs();
		
		List<DatesVoyage> datesVoyages = service.getDatesVoyagesBy(destinations.get(0).getId());
		
		
		for(DatesVoyage dv : datesVoyages) {
			System.out.println(dv);
		}

//		List<Destination> destinations = dao.getAllDestinations();
//		
//		for(Destination d : destinations) {
//			System.out.println(d);
//			for(DatesVoyage dv : d.getDatesVoyages()) {
//				System.out.println("\t "+dv);
//			}
//		}
		
		emf.close();
	}

}
