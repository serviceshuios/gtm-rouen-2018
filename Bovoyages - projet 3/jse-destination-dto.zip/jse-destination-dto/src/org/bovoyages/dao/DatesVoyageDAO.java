package org.bovoyages.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.bovoyages.entities.DatesVoyage;
import org.bovoyages.entities.Destination;

public class DatesVoyageDAO {
	private EntityManagerFactory emf;

	public DatesVoyageDAO(EntityManagerFactory emf) {
		this.emf = emf;
	}

	public List<DatesVoyage> getDatesVoyagesByDestination(Destination destination){
		return this.getDatesVoyagesByDestination(destination.getId());
	}

	public List<DatesVoyage> getDatesVoyagesByDestination(int destinationId){
		EntityManager em = emf.createEntityManager();
		List<DatesVoyage> datesVoyages = new ArrayList<>();
		Destination destination = em.find(Destination.class, destinationId);
		for(DatesVoyage dv : destination.getDatesVoyages()) {
			datesVoyages.add(dv);
		}
		em.close();		
		return datesVoyages;
	}
	
}
