package org.bovoyages.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.bovoyages.entities.Destination;

public class DestinationDAO {
	private EntityManagerFactory emf;

	public DestinationDAO(EntityManagerFactory emf) {
		this.emf = emf;
	}
	
	public List<Destination> getAllDestinations(){
		EntityManager em = emf.createEntityManager();
		List<Destination> destinations = em.createQuery("FROM Destination",Destination.class)
											.getResultList();
		em.close();
		return destinations;
	}
	
	public Destination getDestinationById(int id) {
		EntityManager em = emf.createEntityManager();
		Destination destination = em.find(Destination.class, id);
		em.close();
		return destination;
	}

}
