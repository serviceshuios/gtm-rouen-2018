package org.bovoyages.entities;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="destinations")
public class Destination implements Serializable{
	@Id @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="pk_destination")
	private int id;
	private String region;
	private String description;
	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name="fk_destination")
	private List<DatesVoyage> datesVoyages;
	
	@ElementCollection(fetch=FetchType.EAGER)
	@CollectionTable(name="images",joinColumns=@JoinColumn(name="fk_destination"))
	@Column(name="image")
	private List<String> images;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public List<DatesVoyage> getDatesVoyages() {
		return datesVoyages;
	}
	public void setDatesVoyages(List<DatesVoyage> datesVoyages) {
		this.datesVoyages = datesVoyages;
	}
	
	
	@Override
	public String toString() {
		return "Destination [id=" + id + ", region=" + region + ", description=" + description + "]";
	}
	public List<String> getImages() {
		return images;
	}
	public void setImages(List<String> images) {
		this.images = images;
	}
	public String getVignette() {
		return images.get(0);
	}

	
}
