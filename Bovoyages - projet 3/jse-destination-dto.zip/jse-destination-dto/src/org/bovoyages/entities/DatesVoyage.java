package org.bovoyages.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="dates_voyages")
public class DatesVoyage implements Serializable{
	@Id @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="pk_date_voyage")
	private int id;
	@Column(name="date_depart")
	private Date aller;
	@Column(name="date_retour")	
	private Date retour;
	private double prixHT;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Date getAller() {
		return aller;
	}
	public void setAller(Date aller) {
		this.aller = aller;
	}
	public Date getRetour() {
		return retour;
	}
	public void setRetour(Date retour) {
		this.retour = retour;
	}
	public double getPrixHT() {
		return prixHT;
	}
	public void setPrixHT(double prixHT) {
		this.prixHT = prixHT;
	}
	@Override
	public String toString() {
		return "DatesVoyage [id=" + id + ", aller=" + aller + ", retour=" + retour + ", prixHT=" + prixHT + "]";
	}
	
	
}
