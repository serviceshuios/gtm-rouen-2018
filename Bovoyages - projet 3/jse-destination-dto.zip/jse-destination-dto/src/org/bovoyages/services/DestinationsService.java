package org.bovoyages.services;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManagerFactory;

import org.bovoyages.dao.DatesVoyageDAO;
import org.bovoyages.dao.DestinationDAO;
import org.bovoyages.dto.DatesVoyageDTO;
import org.bovoyages.dto.DestinationDTO;
import org.bovoyages.entities.DatesVoyage;
import org.bovoyages.entities.Destination;

public class DestinationsService {
	private DestinationDAO destinationDAO;
	private DatesVoyageDAO datesVoyageDAO;
	
	public DestinationsService(EntityManagerFactory emf) {
		destinationDAO = new DestinationDAO(emf);
		datesVoyageDAO = new DatesVoyageDAO(emf);
	}
	
	public List<DestinationDTO> getAllDestinationDTOs(){
		List<Destination> destinations = destinationDAO.getAllDestinations();
		List<DestinationDTO> dtos = new ArrayList<>();
		for(Destination d : destinations) {
			dtos.add(createDestinationDTO(d));
		}
		return dtos;
	}

	private DestinationDTO createDestinationDTO(Destination destination) {
		DestinationDTO dto = new DestinationDTO(destination);
		dto.setImageVignette(destination.getVignette());
		DatesVoyage dvPromo = getDatesVoyagePromo(destination);
		dto.setDatesVoyagePromo(new DatesVoyageDTO(dvPromo));
		return dto;
	}

	public DatesVoyage getDatesVoyagePromo(Destination destination) {
		List<DatesVoyage> datesVoyages = datesVoyageDAO.getDatesVoyagesByDestination(destination);
		DatesVoyage promo = datesVoyages.get(0);
		for(DatesVoyage dv : datesVoyages) {
			if(dv.getPrixHT()<promo.getPrixHT())
				promo = dv;	
		}
		return promo;
	}

	public List<DatesVoyage> getDatesVoyagesBy(int id) {
		// TODO Auto-generated method stub
		return datesVoyageDAO.getDatesVoyagesByDestination(id);
	}

}
