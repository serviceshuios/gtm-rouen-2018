package org.antislashn.bataille;

public enum Couleur {
	COEUR, PIQUE, TREFLE, CARREAU
}
