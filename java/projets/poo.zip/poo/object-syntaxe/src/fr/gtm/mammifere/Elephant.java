package fr.gtm.mammifere;

public class Elephant extends Mammifere {

	@Override
	public void crier() {
		System.out.println("barrie");
	}

}
