package fr.gtm.mammifere;

public class Chat extends Mammifere {
	@Override
	public void crier() {
		System.out.println("miaou miaou");
	}
}
