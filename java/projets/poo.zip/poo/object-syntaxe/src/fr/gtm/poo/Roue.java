package fr.gtm.poo;

/**
 * Modélisation d'une roue
 * @author Adminl
 *
 */
public class Roue {
	private double rayon;
	// à voir inch ou cm
	private double epaisseur;
	
	public double getRayon() {
		return rayon;
	}
	public void setRayon(double rayon) {
		this.rayon = rayon;
	}
	public double getEpaisseur() {
		return epaisseur;
	}
	public void setEpaisseur(double epaisseur) {
		this.epaisseur = epaisseur;
	}
	
}
