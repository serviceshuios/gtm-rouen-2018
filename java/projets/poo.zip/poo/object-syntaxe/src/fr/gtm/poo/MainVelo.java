package fr.gtm.poo;

public class MainVelo {

	public static void main(String[] args) {
		Bicycle velo1 = new ToutTerrain();
		velo1.accelerer(50);
	}

}
