package fr.gtm.mammifere;

public class Chien extends Mammifere {
	@Override
	public void crier() {
		System.out.println("grrrrr oua oua");
	}
}
