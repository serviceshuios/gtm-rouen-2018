package fr.gtm.poo;

public class ToutTerrain extends Bicycle {

}
