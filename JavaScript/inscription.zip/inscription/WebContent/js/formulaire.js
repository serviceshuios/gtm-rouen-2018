function show() {
	var input = document.getElementByName("telephone");
	console.log(input.name);
	console.log(input.type);
	console.log(input.value);
}

function showAllInputs() {
	var inputs = document.getElementsByTagName("input");
	for (var i = 0; i < inputs.length; i++) {
		if (inputs[i].type !== "radio" && inputs[i].type !== "checkbox") {
			console.log(inputs[i].name + " " + inputs[i].type + " value: "
					+ inputs[i].value);
		}
		if (inputs[i].type === "checkbox" || inputs[i].type === "radio") {
			if (inputs[i].checked) {
				console.log(inputs[i].name + " " + inputs[i].type + " value: "
						+ inputs[i].value);
			}
		}
	}

}

function showCheckbox(){
	var elts = document.getElementsByName("langages");
	for(var i=0 ; i<elts.length ; i++){
		console.log(elts[i].checked+" "+elts[i].value);
	}
}

function evenement(event){
	console.log(event);
}

function verifFormulaire(event){
	let ok = true;
	let inputs = document.getElementsByTagName("input");
	for(let i=0 ; i< inputs.length ; i++){
		if(inputs[i].type == "text" && inputs[i].value==""){
			ok=false;
			break;
		}
	}
	if(!ok){
		alert("formulaire incomplet");
		event.preventDefault();
		return false;
	}
	return true;
}

function verifierChampVide(event){
	var elt = event.target;
	var span = document.getElementById("error-"+elt.name);
	if(elt.value==""){
		span.className = "visible";
	}else{
		span.className = "invisible";
	}
}

function init() {
	document.getElementById("test").onclick = evenement;
	document.getElementById("submit").onclick = verifFormulaire;
	document.getElementById("nom").onblur = verifierChampVide;
	document.getElementById("prenom").onblur = verifierChampVide;
	document.getElementById("telephone").onblur = verifierChampVide;
	document.getElementById("email").onblur = verifierChampVide;
}

init();