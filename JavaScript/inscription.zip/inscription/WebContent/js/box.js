function changer(){
	let div = document.getElementById("box");
	let color = div.style.backgroundColor;
	if(color==="blue"){
		div.style.backgroundColor="red";
	}else{
		div.style.backgroundColor="blue";
	}
}


function init() {
	document.getElementById("box").onmousedown = changer;
}

init();