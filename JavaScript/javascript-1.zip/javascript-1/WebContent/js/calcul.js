function calculer(){
	var nb1 = document.getElementById("nb1").value;
	var nb2 = document.getElementById("nb2").value;	
	var op = document.getElementById("op").value;
	if(isNaN(nb1) || isNaN(nb2) || nb1=="" || nb2==""){
		alert("veuillez entrer des nombres");
		return;
	}
	nb1 = parseInt(nb1);
	nb2 = parseInt(nb2);
	var result;
	switch (op) {
	case "1":
		result = nb1 + nb2;
		break;
	case "2":
		result = nb1 - nb2;
		break;
	case "3":
		result = nb1 * nb2;
		break;
	case "4":
		result = nb1 / nb2;
		break;
	default:
		break;
	}
	document.getElementById("resultat").value = result;
}

function init(){
	document.getElementById("btnCalculer").onclick = calculer;
}

init();