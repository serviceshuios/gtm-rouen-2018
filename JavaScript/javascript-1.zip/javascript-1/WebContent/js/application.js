"use strict";
function hello(){
	for(let i=0 ; i<10 ; i++){
		console.log(i);
	}
	console.log("i vaut : "+i)
}

function test(){
	alert(message);
}

function changeIt(texte){
	var obj = document.getElementById("out");
	obj.innerHTML = texte;
}

function transfert(){
	var objInput = document.getElementById("foo");
	var objDiv = document.getElementById("out");
	var texte = objInput.value;
	objDiv.innerText = texte;
	
}

function comparer(a,b){
	return a-b;
}

var f = function(a,b){return a-b;};

function triTableau(){
	var tab = [40, 100, 1, 5, 25, 10];
	tab.sort(f);
	for(var i=0 ; i<tab.length ; i++){
		console.log(tab[i]);
	}
}

function init(){
	document.getElementById("bntHello").onclick = hello;
	document.getElementById("bntTest").onclick = triTableau;
}

init();