function showTableMultiplication(){
	var nb = document.getElementById("nb").value;
	if(isNaN(nb) || nb==""){
		return;
	}
	nb = parseInt(nb);
	document.getElementById("titre").innerHTML = "<h2>Table de "+nb+"</h2>";
	var html = "";
	for(var i=0 ; i<13 ; i++){
		html += "<div>"+nb+" x "+i+" = "+(nb*i)+"</div>";
	}
	document.getElementById("table").innerHTML = html;

}

function init(){
	document.getElementById("show").onclick = showTableMultiplication;
}

init();