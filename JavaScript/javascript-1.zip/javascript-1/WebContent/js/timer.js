/**
 * 
 */
var timer = null;
var nbSecondes;

function majDiv(){
	nbSecondes--;
	if(nbSecondes == 0){
		clearInterval(timer);
		timer = null;
		var son = new Audio("sons/0089.mp3");
		son.play();
	}
	document.getElementById("decompte").innerHTML = "<h2>"+nbSecondes+"</h2>";
}
function decompter(){
	nbSecondes = document.getElementById("nbSecondes").value;
	if(!isNaN(nbSecondes)){
		nbSecondes = parseInt(nbSecondes);
		timer = setInterval(majDiv,1000);
		document.getElementById("decompte").innerHTML = "<h2>"+nbSecondes+"</h2>";
	}
}

function init(){
	document.getElementById("btnStart").onclick = decompter;
}

init();