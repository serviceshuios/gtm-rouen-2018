package fr.gtm.contact.servlets;

import java.io.IOException;
import java.util.logging.Logger;

import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import fr.gtm.contact.Constantes;
import fr.gtm.contact.dao.ContactDAO;
import fr.gtm.contact.entities.Contact;

/**
 * Servlet implementation class ShowFormContactServlet
 */
@WebServlet("/ShowFormContactServlet")
public class ShowFormContactServlet extends HttpServlet {
	private static final Logger LOG = Logger.getLogger(ShowFormContactServlet.class.getName());
	private static final long serialVersionUID = 1L;
	@EJB private ContactDAO dao;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idStr = request.getParameter("id");
		if(idStr!=null) {
			try{
				int id = Integer.parseInt(idStr);
				Contact c = dao.getContactById(id);
				request.setAttribute("contact", c);
			}catch(Exception e) {
				LOG.warning("Problème sur id : "+idStr );
			}
		}
		
		String page = "/contact_form.jsp";
		RequestDispatcher rd = getServletContext().getRequestDispatcher(page);
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
