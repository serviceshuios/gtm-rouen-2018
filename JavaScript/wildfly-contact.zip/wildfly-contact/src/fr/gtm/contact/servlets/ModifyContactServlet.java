package fr.gtm.contact.servlets;

import java.io.IOException;
import java.util.List;
import java.util.logging.Logger;

import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import fr.gtm.contact.Constantes;
import fr.gtm.contact.dao.ContactDAO;
import fr.gtm.contact.entities.Contact;

/**
 * Servlet implementation class ModifyContactServlet
 */
@WebServlet("/ModifyContactServlet")
public class ModifyContactServlet extends HttpServlet {
	private static final Logger LOG = Logger.getLogger(ModifyContactServlet.class.getName());
	private static final long serialVersionUID = 1L;
	@EJB private ContactDAO dao;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idStr = request.getParameter("id");
		if(idStr!=null) {
			try{
				int id = Integer.parseInt(idStr);
				Contact c = dao.getContactById(id);
				c.setCivilite(request.getParameter("civilite"));
				c.setNom(request.getParameter("nom"));
				c.setPrenom(request.getParameter("prenom"));
				dao.update(c);
			}catch(Exception e) {
				LOG.warning("Problème sur id : "+idStr );
			}
		}
		List<Contact> contacts = dao.getAllContacts();
		request.setAttribute("contacts", contacts);
		String page = "/view_all_contacts.jsp";
		RequestDispatcher rd = getServletContext().getRequestDispatcher(page);
		rd.forward(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
