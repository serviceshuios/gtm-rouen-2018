package fr.gtm.contact;

public interface Constantes {
	String CONTACT_DAO = "ContactDAO";
	String ENREGISTREMNTS_PAR_PAGE = "enregistrementsParPage";
	String LAST_ID = "lastId";
}
