package fr.gtm.contact.dao;

import java.util.List;

import javax.ejb.Singleton;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;

import fr.gtm.contact.entities.Contact;

@Singleton
public class ContactDAO {
	@PersistenceContext(name="contacts") private EntityManager em;

	public ContactDAO() {

	}
	
	public Contact getContactById(int id) {

		return em.find(Contact.class, id);
	}


	public void saveOrUpdate(Contact contact) {
		if(contact.getId()==0) {
			save(contact);
		}else {
			update(contact);
		}
	}
	public void save(Contact contact) {
		em.persist(contact);
	}

	public void update(Contact contact) {
		em.merge(contact);
	}

	public void remove(Contact contact) {
		Contact c1 = em.find(Contact.class, contact.getId());
		em.remove(c1);
	}

	public List<Contact> getAllContacts() {
		List<Contact> contacts = em.createNamedQuery("allContacts",Contact.class).getResultList();
		return contacts;
	}
	
	@SuppressWarnings("unchecked")
	public List<Contact> getAllContactsByPage(int id, int limit) {
		String sql = "SELECT * FROM personnes WHERE pk> :id LIMIT :limit";
		
		List<Contact> contacts = em.createNativeQuery(sql,Contact.class)
									.setParameter("id", id)
									.setParameter("limit",limit)
									.getResultList();
		return contacts;
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
