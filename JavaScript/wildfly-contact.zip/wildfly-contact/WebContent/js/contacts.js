"use strict";

let xhr = new XMLHttpRequest();

function showOneContact(data){
	console.log("show => "+data);
	let contact = JSON.parse(data);
	let container = document.getElementById("container");
	let html = "<table>";
	html += "<tr>";
	html += "<td>"+contact.civilite+"</td>";
	html += "<td>"+contact.prenom+"</td>";
	html += "<td>"+contact.nom+"</td>";
	html += "</tr>";
	html += "</table>";
	container.innerHTML = html;
}

function searchById(){
	let id = document.getElementById("id").value;

	let url = "rest/contacts/id/"+id;
	xhr.onreadystatechange=function(){		
		if(xhr.readyState==4 && xhr.status==200){
			showOneContact(xhr.responseText);
		}
	}
	xhr.open("GET",url,true);
	xhr.send(null);
}

function showAddResponse(data){
	alert(data);
}
function addContact(){
	let civilite = document.getElementById("civilite").value;
	let nom = document.getElementById("nom").value;
	let prenom = document.getElementById("prenom").value;
	let contact = {id:0,civilite:civilite,nom:nom,prenom:prenom};
	let url = "rest/contacts/add";
	xhr.onreadystatechange=function(){		
		if(xhr.readyState==4 && xhr.status==200){
			showAddResponse(xhr.responseText);
		}
	}
	xhr.open("POST",url,true);
	xhr.setRequestHeader("Content-Type", "application/json");
	xhr.send(JSON.stringify(contact));
}

document.addEventListener("DOMContentLoaded",function(){
	document.getElementById("searchById").addEventListener("click",searchById);
	document.getElementById("addContact").addEventListener("click",addContact);
});