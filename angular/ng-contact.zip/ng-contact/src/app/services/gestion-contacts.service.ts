import { Injectable } from '@angular/core';
import { Contact } from '../model/contact';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class GestionContactsService {
  private host = 'http://localhost:8080/rest-contacts/rest/';

  contacts: Contact[] = [];

  constructor(private http: HttpClient) {
  }

  getAllContacts() {
    return this.http.get(`${this.host}contacts/all`);
  }

  getContactsByDebutNom(debutNom: string) {
    return this.http.get(`${this.host}contacts/nom/${debutNom}`);
  }

  delContactById(id: Number) {
    return this.http.delete(`${this.host}contacts/del/${id}`, { responseType: 'text' });
  }

  addContact(contact: Contact) {
    return this.http.post(`${this.host}contacts/new`, contact, { responseType: 'text' });
  }

}
