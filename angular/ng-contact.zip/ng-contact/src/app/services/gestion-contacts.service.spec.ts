import { TestBed } from '@angular/core/testing';

import { GestionContactsService } from './gestion-contacts.service';

describe('GestionContactsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: GestionContactsService = TestBed.get(GestionContactsService);
    expect(service).toBeTruthy();
  });
});
