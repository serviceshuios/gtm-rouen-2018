import { Component} from '@angular/core';
import { Contact } from './model/contact';
import { GestionContactsService } from './services/gestion-contacts.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  contact: Contact = new Contact({civilite: 'M'});
  contacts: Contact[];
  searchNom: string;

  constructor(private gestionContactService: GestionContactsService) {
    this.allContacts();
  }

  addContact() {
    this.gestionContactService.addContact(this.contact).subscribe((data: string) => {
      this.allContacts();
      alert(data);
    } );
    this.contact = new Contact({civilite: 'M'});
  }

  searchByNom() {
    this.gestionContactService.getContactsByDebutNom(this.searchNom).subscribe((datas: Array<Contact>) => {
      this.contacts = datas;
    });
  }

  openDialogBox() {
    console.log('openDialogBox');
  }

  allContacts() {
    this.gestionContactService.getAllContacts().subscribe((datas: Array<Contact>) => {
      this.contacts = datas;
    } );
  }

  delContactById(id: number) {
    this.gestionContactService.delContactById(id).subscribe((data: string) => {
      this.allContacts();
      alert(data);
    } );
  }


}
