export class Contact {
    id: number;
    civilite: string;
    nom: string;
    prenom: string;

    constructor(values: Object = {}) {
        Object.assign(this, values);
    }
}
