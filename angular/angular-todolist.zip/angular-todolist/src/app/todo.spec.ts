import { Todo } from './todo';
describe('Todo', () => {
  it('should create an instance', () => {
    expect(new Todo()).toBeTruthy();
  });
  it('constructeur avec paramètres', () => {
    let todo: Todo;
    todo = new Todo({
      title: 'Task01',
      fini: true
    });
    expect(todo.title).toEqual('Task01');
    expect(todo.fini).toEqual(true);
  });
});
