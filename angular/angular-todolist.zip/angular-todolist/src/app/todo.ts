export class Todo {
    id: number;
    title = '';
    fini = false;

    constructor(values: Object = {}) {
        Object.assign(this, values);
    }
}
