package org.antislashn.contacts.service;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/rest")
public class ContactsConfig extends Application {

}
