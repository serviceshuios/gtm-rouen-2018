package fr.gtm.bovoyage.service;

import java.util.List;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import fr.gtm.bovoyage.dao.DestinationDAO;
import fr.gtm.bovoyage.metier.DatesVoyage;
import fr.gtm.bovoyage.metier.Destination;

public class ServiceCommande {
	private DestinationDAO dDao;

	public ServiceCommande(DataSource ds) {
		dDao = new DestinationDAO(ds);
	}

	public ServiceCommande() throws NamingException {

		InitialContext ctx = new InitialContext();
		DataSource ds = (DataSource) ctx.lookup("java:/comp/env/jdbc/bovoyages");
		dDao = new DestinationDAO(ds);
	}

	public List<Destination> getDestinationByCommande(String idstr) {
		long id = Long.parseLong(idstr);
		return dDao.getDestinationByCommande(id);

	}

	public List<DatesVoyage> getDatesVoyageCommander(String idstr) {
		long id = Long.parseLong(idstr);
		return dDao.getDatesVoyageCommander(id);

	}

}
