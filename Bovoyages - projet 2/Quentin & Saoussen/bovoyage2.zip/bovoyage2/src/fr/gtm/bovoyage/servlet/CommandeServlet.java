package fr.gtm.bovoyage.servlet;

import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;
import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import fr.gtm.bovoyage.metier.DatesVoyage;
import fr.gtm.bovoyage.metier.Destination;
import fr.gtm.bovoyage.service.ServiceCommande;

/**
 * Servlet implementation class CommandeServlet
 */
/**
 * @author Adminl
 *
 */
@WebServlet("/CommandeServlet")
public class CommandeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ServiceCommande service;

	@Resource(name = "jdbc/bovoyages")
	private DataSource dataSource;

	@Override
	public void init() throws ServletException {
		try {
			service = new ServiceCommande();
		} catch (NamingException e) {
			throw new ServletException(e);
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String idstr = request.getParameter("id");
		if (idstr != null) {
			service.getDestinationByCommande(idstr);
			service.getDatesVoyageCommander(idstr);
		}
		List<Destination> destinations = service.getDestinationByCommande(idstr);
		List<DatesVoyage> datesvoyage = service.getDatesVoyageCommander(idstr);
		request.setAttribute("destinations", destinations);
		request.setAttribute("datesvoyages", datesvoyage);

		String page = "/Commander.jsp";
		RequestDispatcher rd = getServletContext().getRequestDispatcher(page);
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
