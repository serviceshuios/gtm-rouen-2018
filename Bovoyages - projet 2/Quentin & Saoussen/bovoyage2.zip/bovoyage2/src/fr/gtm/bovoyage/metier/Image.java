package fr.gtm.bovoyage.metier;

public class Image {
	private String image;

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

}
