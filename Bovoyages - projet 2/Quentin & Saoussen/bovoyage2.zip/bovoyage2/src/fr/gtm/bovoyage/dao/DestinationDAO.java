package fr.gtm.bovoyage.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sql.DataSource;
import fr.gtm.bovoyage.metier.DatesVoyage;
import fr.gtm.bovoyage.metier.Destination;
import fr.gtm.bovoyage.metier.Image;

public class DestinationDAO {
	private DataSource dataSource;
	private static final Logger LOG = Logger.getLogger(DestinationDAO.class.getName());

	public DestinationDAO(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public List<Destination> getAllDestination() {
		List<Destination> destinations = new ArrayList<>();
		String sql = "SELECT  region,pk_destination, image FROM destinations d, images im WHERE pk_destination = fk_destination group by pk_destination";
		try (Connection connection = dataSource.getConnection()) {
			PreparedStatement ps = connection.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Destination d = builDestination(rs);
				destinations.add(d);
			}
		} catch (SQLException e) {
			LOG.log(Level.SEVERE, "Erreur", e);
		}
		return destinations;
	}

	public List<Destination> getDestinationById(Long id) {
		List<Destination> destination = new ArrayList<>();
		String sql = "SELECT * FROM destinations WHERE pk_destination=?";
		try (Connection connection = dataSource.getConnection()) {
			PreparedStatement ps = connection.prepareStatement(sql);
			ps.setLong(1, id);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Destination d = builDestinationById(rs);
				destination.add(d);
			}
		} catch (SQLException e) {
			LOG.log(Level.SEVERE, "Erreur", e);
		}
		return destination;
	}

	public List<DatesVoyage> getDatesVoyageById(Long id) {
		List<DatesVoyage> datesvoyages = new ArrayList<>();
		String sql = "SELECT * FROM  dates_voyages WHERE fk_destination =?";
		try (Connection connection = dataSource.getConnection()) {
			PreparedStatement ps = connection.prepareStatement(sql);
			ps.setLong(1, id);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				DatesVoyage dv = buildVoyageById(rs);
				datesvoyages.add(dv);
			}
		} catch (SQLException e) {
			LOG.log(Level.SEVERE, "Erreur", e);
		}
		return datesvoyages;
	}

	public List<Image> getImage(Long id) {
		List<Image> images = new ArrayList<>();
		String sql = "SELECT * FROM  images WHERE fk_destination =?";
		try (Connection connection = dataSource.getConnection()) {
			PreparedStatement ps = connection.prepareStatement(sql);
			ps.setLong(1, id);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Image im = buildImage(rs);
				images.add(im);
			}
		} catch (SQLException e) {
			LOG.log(Level.SEVERE, "Erreur", e);
		}
		return images;
	}

	public List<Destination> getDestinationByCommande(long id) {
		List<Destination> destinations = new ArrayList<>();
		String sql = "SELECT de.region FROM  destinations de, "
				+ "dates_voyages dv WHERE de.pk_destination=dv.fk_destination "
				+ "AND dv.pk_date_voyage=? GROUP BY de.region";
		try (Connection connection = dataSource.getConnection()) {
			PreparedStatement ps = connection.prepareStatement(sql);
			ps.setLong(1, id);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Destination de = buildDestinationByCommande(rs);
				destinations.add(de);
			}
		} catch (SQLException e) {
			LOG.log(Level.SEVERE, "Erreur", e);
		}

		return destinations;

	}

	public List<DatesVoyage> getDatesVoyageCommander(long id) {
		List<DatesVoyage> datesvoyages = new ArrayList<>();
		try (Connection connexion = dataSource.getConnection()) {
			String sql = "SELECT * FROM dates_voyages WHERE pk_date_voyage = ? ";
			PreparedStatement ps = connexion.prepareStatement(sql);
			ps.setLong(1, id);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				DatesVoyage dv = buildDatesVoyageCommander(rs);
				datesvoyages.add(dv);
			}
		} catch (SQLException e) {
			LOG.log(Level.SEVERE, "Erreur", e);
		}
		return datesvoyages;
	}

	private DatesVoyage buildDatesVoyageCommander(ResultSet rs) throws SQLException {
		DatesVoyage dv = new DatesVoyage();
		dv.setDateAller(rs.getDate("date_depart"));
		dv.setDateRetour(rs.getDate("date_retour"));
		dv.setPrixHT(rs.getDouble("prixHT"));
		dv.setId_pk(rs.getLong("pk_date_voyage"));
		return dv;
	}

	private Destination buildDestinationByCommande(ResultSet rs) throws SQLException {
		Destination de = new Destination();
		de.setRegion(rs.getString("region"));
		return de;
	}

	private Image buildImage(ResultSet rs) throws SQLException {
		Image im = new Image();
		im.setImage(rs.getString("image"));
		return im;
	}

	private DatesVoyage buildVoyageById(ResultSet rs) throws SQLException {
		DatesVoyage dv = new DatesVoyage();
		dv.setDateAller(rs.getDate("date_depart"));
		dv.setDateRetour(rs.getDate("date_retour"));
		dv.setPrixHT(rs.getDouble("prixHT"));
		dv.setId_pk(rs.getLong("pk_date_voyage"));
		return dv;
	}

	private Destination builDestinationById(ResultSet rs) throws SQLException {

		Destination d = new Destination();
		d.setId(rs.getLong("pk_destination"));
		d.setRegion(rs.getString("region"));
		d.setDescription(rs.getString("description"));

		return d;
	}

	private Destination builDestination(ResultSet rs) throws SQLException {
		Destination d = new Destination();
		d.setId(rs.getLong("pk_destination"));
		d.setRegion(rs.getString("region"));
		d.setImage(rs.getString("image"));
		return d;
	}

}
