package fr.gtm.bovoyage.service;

import java.util.List;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import fr.gtm.bovoyage.dao.DestinationDAO;
import fr.gtm.bovoyage.metier.Destination;

public class ServiceAllDestination {
	private DestinationDAO dDao;

	public ServiceAllDestination(DataSource ds) {
		dDao = new DestinationDAO(ds);
	}

	public ServiceAllDestination() throws NamingException {

		InitialContext ctx = new InitialContext();
		DataSource ds = (DataSource) ctx.lookup("java:/comp/env/jdbc/bovoyages");
		dDao = new DestinationDAO(ds);
	}

	public List<Destination> getAllDestinations() {
		return dDao.getAllDestination();
	}
}