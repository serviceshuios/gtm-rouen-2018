package fr.gtm.bovoyage.service;

import java.util.List;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import fr.gtm.bovoyage.dao.DestinationDAO;
import fr.gtm.bovoyage.metier.DatesVoyage;
import fr.gtm.bovoyage.metier.Destination;
import fr.gtm.bovoyage.metier.Image;

public class ServiceDestinationById {
	private DestinationDAO dDao;

	public ServiceDestinationById(DataSource ds) {
		dDao = new DestinationDAO(ds);
	}

	public ServiceDestinationById() throws NamingException {

		InitialContext ctx = new InitialContext();
		DataSource ds = (DataSource) ctx.lookup("java:/comp/env/jdbc/bovoyages");
		dDao = new DestinationDAO(ds);
	}

	public List<Destination> getDestinationById(String idstr) {
		Long id = Long.parseLong(idstr);
		return dDao.getDestinationById(id);
	}

	public List<DatesVoyage> getDatesVoyageById(String idstr) {
		Long id = Long.parseLong(idstr);
		return dDao.getDatesVoyageById(id);
	}

	public List<Image> getImage(String idstr) {
		Long id = Long.parseLong(idstr);
		return dDao.getImage(id);
	}
}
