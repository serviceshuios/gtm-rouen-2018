package fr.gtm.bovoyage.repos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.sql.DataSource;

import fr.gtm.bovoyages.dao.DestinationDAO;
import fr.gtm.bovoyages.entities.DatesVoyage;
import fr.gtm.bovoyages.entities.Destination;

/**
 * Implementation des différentes méthode de l'interface Destination DAO
 * @author Pia & Nadir
 *
 */
public class DestinationRepository implements DestinationDAO {
	private static final Logger LOG = Logger.getLogger(DestinationRepository.class.getName());
	private DataSource ds;
	
	public DestinationRepository(DataSource ds) {
		super();
		this.ds=ds;
	}

	@Override
	public Destination save(Destination destination) {
		
		return null;
	}

	@Override
	public void delete(Destination destination) {
		

	}

	@Override
	public void update(Destination destination) {
		

	}
	
	@Override
	public List<Destination> getDestinationsByRegion(String region) {
		List<Destination> destinations = new ArrayList<>();
		try(Connection con = ds.getConnection()){

			String sql = "SELECT d.description, d.region, d.pk_destination FROM destinations d "
					+ " where region = ? ";

			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, region);

			ResultSet rs = ps.executeQuery();

			LOG.info(">>>>> accee au base de donnée getDestinationsByRegion");

			while(rs.next()) {
				LOG.info(">>>>> rs  au base de donnée");

				destinations.add(createDestination(rs));

			}

			return destinations;
		} catch (SQLException e) {
			LOG.log(Level.SEVERE, ">>>>>>>>>> Erreur", e);
		}

		return null;
	}

	

	@Override
	public Destination getDestinationById(long id) {
		Destination destination =null;
		try(Connection con = ds.getConnection()){
			
			String sql = "SELECT d.description, d.region, d.pk_destination FROM destinations d "
					+ " where d.pk_destination= ?";
						
			PreparedStatement ps = con.prepareStatement(sql);
							ps.setLong(1, id);
							
			ResultSet rs = ps.executeQuery();
			
			LOG.info(">>>>> accee au base de donnée  getDestinationById");
			
			while(rs.next()) {
				LOG.info(">>>>> rs  au base de donnée");
				
				destination = createDestination(rs); 
				
			}
			
			return destination;
		} catch (SQLException e) {
			LOG.log(Level.SEVERE, ">>>>>>>>>> Erreur", e);
		}
		
		return destination;
	}

	@Override
	public List<DatesVoyage> getDatesVoyages(Destination destination) {
		List<DatesVoyage> datesvoyages = new ArrayList<>();
		
		try(Connection con = ds.getConnection()){
			long id = destination.getId();
			String sql = "SELECT dv.pk_date_voyage,dv.date_depart,dv.date_retour,dv.prixHT FROM dates_voyages dv where dv.fk_destination = ? ";
						
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setLong(1, id);
			
				ResultSet rs = ps.executeQuery();
			
			LOG.info(">>>>> accee au base de donnée getDatesVoyages");
			
			while(rs.next()) {
				
				
				datesvoyages.add(createDatesVoyages(rs));
				
			}
			
			return datesvoyages;
		} catch (SQLException e) {
			LOG.log(Level.SEVERE, ">>>>>>>>>> Erreur", e);
		}
		return null;
	}

	private DatesVoyage createDatesVoyages(ResultSet rs) throws SQLException {
		DatesVoyage datesVoyage = new DatesVoyage();
		
			datesVoyage.setDateAller(rs.getDate("date_depart"));
			datesVoyage.setDateRetour(rs.getDate("date_retour"));
			datesVoyage.setPrixHT(rs.getDouble("prixHT"));
			datesVoyage.setId(rs.getLong("pk_date_voyage"));
			
			
		return datesVoyage;
	}

	@Override
	public List<Destination> getAllDestinations() {
		List<Destination> destinations = new ArrayList<>();
	
		try(Connection con = ds.getConnection()){
			
			String sql = "SELECT d.description, d.region, d.pk_destination FROM destinations d ";
						
			Statement st = con.createStatement();
			
			ResultSet rs = st.executeQuery(sql);
			
			LOG.info(">>>>> accee au base de donnée");
			
			while(rs.next()) {
				LOG.info(">>>>> rs  au base de donnée");
				
				destinations.add(createDestination(rs));
				
			}
			
			return destinations;
		} catch (SQLException e) {
			LOG.log(Level.SEVERE, ">>>>>>>>>> Erreur", e);
		}
		
		return null;
	}
	
	private Destination createDestination(ResultSet rs) throws SQLException {
		
		Destination destination = new Destination();
		
		destination.setDescription(rs.getString("description"));
		destination.setRegion(rs.getString("region"));
		long fk_destination = rs.getLong("pk_destination");
		
		destination.setId(fk_destination);
		
		destination.setImages(getImagesById(fk_destination));
		LOG.info(">>>>> rs  au base de donnée destination");
		return destination;
	}
	
	private List<String> getImagesById(long id){
		
		List<String> images =new ArrayList<>();
		try(Connection con = ds.getConnection()){
			
			String sql = "Select i.image from images i where i.fk_destination = ?";			
			PreparedStatement ps=con.prepareStatement(sql);
								ps.setLong(1, id);								
			ResultSet rs = ps.executeQuery();
			LOG.info(">>>>> rs  au base de donnée image");
			while(rs.next()) {
				images.add(rs.getString("image"));
			}
			
		} catch (SQLException e) {
			LOG.log(Level.SEVERE, ">>>>>>>>>> Erreur", e);
		}
		
		return images;
	}
	

}
