package fr.gtm.bovoyage.servlet;

import java.io.IOException;
import java.util.List;
import java.util.logging.Logger;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import fr.gtm.bovoyages.entities.DatesVoyage;
import fr.gtm.bovoyages.entities.Destination;
import fr.gtm.bovoyages.facades.DestinationFacade;

/**
 * Servlet implementation class DetailsDestinationServlet
 * Servlet qui affiche les détails de la destination
 * @author Pia & Nadir
 */
@WebServlet("/DetailsDestinationServlet")
public class DetailsDestinationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static final Logger LOG=Logger.getLogger(ListeDestinatination.class.getName());	
	private static DestinationFacade service;
	
	@Resource(name="jdbc/bovoyages") DataSource ds;
	@Override
	public void init() throws ServletException {
			service = new DestinationFacade(ds);
			LOG.info(">>>>>>>>>> servlet ");
	}


	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
			Destination destination=null;
			
			long idDestination= Long.valueOf(request.getParameter("destination-id"));
			
			List<DatesVoyage> datesVoyages = service.getDatesVoyages(idDestination);
			List<Destination> destinations = service.getAllDestinations();
			 
			 for (Destination dest : destinations) {
				if (dest.getId() == idDestination ) {
					destination=dest;
				}
			}
			
			 LOG.info(">>>>>>>>>> servlet getDatesVoyages");
	
		request.setAttribute("destination", destination);
		request.setAttribute("datesvoyages", datesVoyages);
		String page = "/jsp/details.jsp";
		
		RequestDispatcher rd = getServletContext().getRequestDispatcher(page);
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
