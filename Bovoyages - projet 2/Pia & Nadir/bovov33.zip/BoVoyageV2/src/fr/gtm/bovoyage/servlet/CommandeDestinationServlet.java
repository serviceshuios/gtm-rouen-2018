package fr.gtm.bovoyage.servlet;

import java.io.IOException;
import java.util.List;
import java.util.logging.Logger;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import fr.gtm.bovoyages.entities.DatesVoyage;
import fr.gtm.bovoyages.entities.Destination;
import fr.gtm.bovoyages.entities.Voyage;
import fr.gtm.bovoyages.facades.DestinationFacade;

/**
 * Servlet implementation class CommandeDestinationServlet
 * Servlet permet d'affciher la commande choisie
 * @author Pia & Nadir
 * 
 */
@WebServlet("/CommandeDestinationServlet")
public class CommandeDestinationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger LOG=Logger.getLogger(ListeDestinatination.class.getName());	
	private static DestinationFacade service;
	
	@Resource(name="jdbc/bovoyages") DataSource ds;	 
	@Override
	public void init() throws ServletException {
			service = new DestinationFacade(ds);
			LOG.info(">>>>>>>>>> servlet ");
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		LOG.info(">>>>>>>>>> servlet  CommandeDestinationServlet");
		DatesVoyage datesVoyage = null;
		Destination destination = null;
		int nbrPersonne = 1;
		
		double prixTotal = 0;
		
		
		long idDateVoyage= Long.valueOf(request.getParameter("datevoyage-id"));
		long idDestination = Long.valueOf(request.getParameter("destination-id"));
		
	

		
		request.setAttribute("datevoyageid", idDateVoyage);
		request.setAttribute("destinationid", idDestination);
		
		
		String  nbPersonnes =request.getParameter("nbVoyageur-id");
		
		if(nbPersonnes !=null) {
			nbrPersonne=Integer.valueOf(nbPersonnes);
		}
		
		

		LOG.info(">>>>>>>>>> servlet  CommandeDestinationServlet");
		
	
		List<DatesVoyage> datesvoyages= service.getDatesVoyages(idDestination);
		List<Destination> destinations = service.getAllDestinations();
		
		for(DatesVoyage datVoy : datesvoyages) {
			if(datVoy.getId() == idDateVoyage) {
				datesVoyage=datVoy;
			}
		}
		for (Destination dest : destinations) {
			if (dest.getId() == idDestination ) {
				destination=dest;
			}
		}
		
			Voyage voyage = new Voyage();
			voyage.setRegion(destination.getRegion());
			voyage.setDatesVoyage(datesVoyage);
			
			// mise à jour du prix total
			prixTotal=nbrPersonne*voyage.getPrixHT();
			
		
			request.setAttribute("nbVoyaid", nbrPersonne);
			request.setAttribute("prixTotal", prixTotal);
			request.setAttribute("voyage", voyage);
			
		
			
		String page = "/jsp/commande.jsp";
		
		RequestDispatcher rd = getServletContext().getRequestDispatcher(page);
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
