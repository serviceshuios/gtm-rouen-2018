package fr.gtm.bovoyages.facades;

import java.util.List;

import javax.sql.DataSource;

import fr.gtm.bovoyage.repos.DestinationRepository;
import fr.gtm.bovoyages.dao.DestinationDAO;
import fr.gtm.bovoyages.entities.DatesVoyage;
import fr.gtm.bovoyages.entities.Destination;


/**
 * Façade utilisée par la couche de présentation.<br>
 * Cette façade permet à la couche de présentation de ne pas manipuler
 * les DAO
 * @author franck
 *
 */
public class DestinationFacade {
	private DestinationDAO dao;
	
	
	public DestinationFacade(DataSource ds) {
		dao = new DestinationRepository(ds);
	}
	
	public List<Destination> getAllDestinations(){
		return dao.getAllDestinations();
	}
	
	public List<DatesVoyage> getDatesVoyages(Destination destination) {
		return dao.getDatesVoyages(destination);
	}
	
	public List<Destination> getDestinationsByRegion(String region){
		return dao.getDestinationsByRegion(region);
	}
	
	public List<DatesVoyage> getDatesVoyages(long idDestination){
		Destination destination = dao.getDestinationById(idDestination);
		return dao.getDatesVoyages(destination);
	}

}
