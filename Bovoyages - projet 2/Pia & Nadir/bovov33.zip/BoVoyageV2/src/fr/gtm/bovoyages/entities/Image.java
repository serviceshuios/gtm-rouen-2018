package fr.gtm.bovoyages.entities;

public class Image {

}
