package fr.gtm.bovoyages.dao;

import java.util.List;

import fr.gtm.bovoyages.entities.DatesVoyage;
import fr.gtm.bovoyages.entities.Destination;

/**
 * Interface DAO<br>
 * Contient l'ensemble des méthodes permettant la gestion des enregistrements pour une Destination
 */
public interface DestinationDAO {
	
	Destination save(Destination destination);
	void delete(Destination destination);
	void update(Destination destination);
	List<Destination> getDestinationsByRegion(String region);
	Destination getDestinationById(long id);
	List<DatesVoyage> getDatesVoyages(Destination destination);
	List<Destination> getAllDestinations();
}
