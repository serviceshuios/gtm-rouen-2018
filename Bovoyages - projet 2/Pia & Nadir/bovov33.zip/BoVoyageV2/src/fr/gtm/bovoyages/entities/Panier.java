package fr.gtm.bovoyages.entities;

import java.util.HashMap;
import java.util.Map;



public class Panier {
	
	private Destination destination;
	private DatesVoyage datesvoyages;
	
	private Map<Destination, DatesVoyage> mapDistinationDateVoyage = new HashMap<>();
	
}
