package fr.gtm.bovoyages.servlets;

import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import fr.gtm.bovoyages.entities.DatesVoyage;
import fr.gtm.bovoyages.entities.Destination;
import fr.gtm.bovoyages.facades.CommandeFacade;


@WebServlet("/ShowCommandeServlets")
public class ShowCommandeServlets extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static CommandeFacade facades;

	@Resource(name = "jdbc/bovoyages")
	private DataSource dataSource;
	
	@Override
	public void init() throws ServletException {
		facades = new CommandeFacade(dataSource);
	}  


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idStr = request.getParameter("id");
		request.setAttribute("idStr", idStr);

		List<DatesVoyage> datesVoyages = facades.getDatesVoyageCommande(idStr);
		request.setAttribute("datesVoyages", datesVoyages);
		
		List<Destination> destinations = facades.getDestinationByCommande(idStr);
		request.setAttribute("destinations", destinations);
		
		String page = "/show_commande.jsp";
		
		RequestDispatcher rd = getServletContext().getRequestDispatcher(page);
		rd.forward(request, response);
		
	}
	


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
