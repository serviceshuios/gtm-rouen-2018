package fr.gtm.bovoyages.facades;

import java.util.List;
import javax.sql.DataSource;
import fr.gtm.bovoyages.dao.VoyageDAO;
import fr.gtm.bovoyages.entities.DatesVoyage;
import fr.gtm.bovoyages.entities.Destination;
import fr.gtm.bovoyages.entities.Image;


public class VoyageFacade {
	private VoyageDAO dao;


	public VoyageFacade(DataSource dataSource) {
		dao = new VoyageDAO(dataSource);
	}
	
	public List<DatesVoyage> getDatesVoyageById(String idStr){
		long id = Long.parseLong(idStr);
		return dao.getDatesVoyageById(id);
		
	}
	
	public List<Destination> getDestinationById(String idStr) {
		long id = Long.parseLong(idStr);
		return dao.getDestinationById(id);
	}
	public List<Image> getImageById(String idStr) {
		long id = Long.parseLong(idStr);
		return dao.getImageById(id);
	}
}
