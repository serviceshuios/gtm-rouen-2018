package fr.gtm.bovoyages.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sql.DataSource;
import fr.gtm.bovoyages.entities.DatesVoyage;
import fr.gtm.bovoyages.entities.Destination;
import fr.gtm.bovoyages.entities.Image;


public class VoyageDAO {

	private static final Logger LOG = Logger.getLogger(VoyageDAO.class.getName());
	private DataSource dataSource;

	public VoyageDAO(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public List<DatesVoyage> getDatesVoyageById(long id) {
		List<DatesVoyage> datesVoyages = new ArrayList<>();
		String sql = "SELECT * FROM dates_voyages WHERE fk_destination=?";
		try (Connection connection = dataSource.getConnection()) {
			PreparedStatement pstmt = connection.prepareStatement(sql);
			pstmt.setLong(1, id);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				DatesVoyage dv = buildDatesVoyageById(rs);
				datesVoyages.add(dv);
			}

		} catch (SQLException e) {
			LOG.log(Level.SEVERE, "Erreur", e);
		}
		return datesVoyages;

	}
	
	public List<Destination> getDestinationById(long id) {
		List<Destination> destinations = new ArrayList<>();
		try (Connection connexion = dataSource.getConnection()) {
			String SQL = "SELECT * FROM destinations WHERE pk_destination = ?";
			PreparedStatement pstmt = connexion.prepareStatement(SQL);
			pstmt.setLong(1, id);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				destinations.add(buildDestinationById(rs));
			}
		} catch (SQLException e) {
			LOG.log(Level.SEVERE, "Erreur", e);
		}
		return destinations ;
	}
	public List<Image> getImageById(long id) {
		List<Image> images = new ArrayList<>();
		try (Connection connexion = dataSource.getConnection()) {
			String SQL = "SELECT * FROM images WHERE  fk_destination = ?";
			PreparedStatement pstmt = connexion.prepareStatement(SQL);
			pstmt.setLong(1, id);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				images.add(buildImageById(rs));
			}
		} catch (SQLException e) {
			LOG.log(Level.SEVERE, "Erreur", e);
		}
		return images ;
	}
	

	private Image buildImageById(ResultSet rs) throws SQLException {
		Image i = new Image();
		i.setImage(rs.getString(1));
		i.setId(rs.getLong(2));
		return i;
	}

	private DatesVoyage buildDatesVoyageById(ResultSet rs) throws SQLException {
		DatesVoyage dv = new DatesVoyage();
		dv.setId(rs.getLong(1));
		dv.setDateAller(rs.getDate(2));
		dv.setDateRetour(rs.getDate(3));
		dv.setPrixHT(rs.getDouble(4));
		return dv;
	}
	private Destination buildDestinationById(ResultSet rs) throws SQLException {
		Destination d = new Destination();
		d.setId(rs.getLong(1));
		d.setRegion(rs.getString(2));
		d.setDescription(rs.getString(3));
				return d;
	}
}
