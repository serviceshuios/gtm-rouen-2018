package fr.gtm.bovoyages.facades;

import java.util.List;
import javax.sql.DataSource;
import fr.gtm.bovoyages.dao.DestinationDAO;
import fr.gtm.bovoyages.entities.DatesVoyage;
import fr.gtm.bovoyages.entities.Destination;

public class DestinationFacade {

	private DestinationDAO dao;


	public DestinationFacade(DataSource dataSource) {
		dao = new DestinationDAO(dataSource);
	}

	public List<Destination> getAllDestinations() {
		return dao.getAllDestinations();
	}
	
}
