package fr.gtm.bovoyages.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sql.DataSource;
import fr.gtm.bovoyages.entities.Destination;

public class DestinationDAO {

	private static final Logger LOG = Logger.getLogger(DestinationDAO.class.getName());
	private DataSource dataSource;

	public DestinationDAO(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public List<Destination> getAllDestinations() {
		List<Destination> destinations = new ArrayList<>();
		String sql = "SELECT pk_destination, region, image, description FROM destinations, images WHERE destinations.pk_destination=images.fk_destination GROUP BY destinations.pk_destination";
		try (Connection connection = dataSource.getConnection()) {
			Statement stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				Destination d = buildDestination(rs);
				destinations.add(d);
			}
		} catch (SQLException e) {
			LOG.log(Level.SEVERE, "Erreur", e);
		}

		return destinations;
	}

	private Destination buildDestination(ResultSet rs) throws SQLException {
		Destination d = new Destination();
		d.setId(rs.getLong(1));
		d.setRegion(rs.getString(2));
		d.setImage(rs.getString(3));
		d.setDescription(rs.getString(4));
		return d;
	}
}
