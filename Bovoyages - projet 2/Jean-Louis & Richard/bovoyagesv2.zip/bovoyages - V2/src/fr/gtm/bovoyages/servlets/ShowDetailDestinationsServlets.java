package fr.gtm.bovoyages.servlets;

import java.io.IOException;
import java.util.List;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import fr.gtm.bovoyages.entities.DatesVoyage;
import fr.gtm.bovoyages.entities.Destination;
import fr.gtm.bovoyages.entities.Image;
import fr.gtm.bovoyages.facades.VoyageFacade;

@WebServlet("/ShowDetailDestinationsServlets")
public class ShowDetailDestinationsServlets extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static VoyageFacade facades;
	private static final Logger LOG = Logger.getLogger(ShowDetailDestinationsServlets.class.getName());
	// Injection !!!
	@Resource(name = "jdbc/bovoyages")
	private DataSource dataSource;

	@Override
	public void init() throws ServletException {
		facades = new VoyageFacade(dataSource);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	
		String idStr= request.getParameter("id");

		request.setAttribute("idStr", idStr);
		List<DatesVoyage> datesVoyages = facades.getDatesVoyageById(idStr);
		request.setAttribute("datesVoyages", datesVoyages);
		List<Destination> destinations = facades.getDestinationById(idStr);
		request.setAttribute("destinations", destinations);
		List<Image> images = facades.getImageById(idStr);
		request.setAttribute("images", images);

		String page = "/show_detail_destinations.jsp";
		
		RequestDispatcher rd = getServletContext().getRequestDispatcher(page);
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
