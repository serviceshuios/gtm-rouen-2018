package fr.bovoyage.service;

import java.util.List;

import javax.sql.DataSource;

import fr.bovoyage.dao.DestinationDAO;
import fr.bovoyage.entites.DatesVoyage;
import fr.bovoyage.entites.Destination;
import fr.bovoyage.entites.Images;
/**
 * GestionDestinationService<br>
 * Contient l'appel des méthodes permettant la gestion des destinations et
 * des dates de voyages
 * 
 * @author Thomas & Moussa
 *
 */
public class GestionDestinationService {

	private DestinationDAO dao;

	public GestionDestinationService(DataSource dataSource) {
		dao = new DestinationDAO(dataSource);
	}

	/**
	 * getAllDestinations()<br>
	 * Appel la méthode getAllDestinations()
	 *
	 */
	public List<Destination> getAllDestinations() {
		return dao.getAllDestinations();
	}

	/**
	 * getDatesVoyageById(String idStr)<br>
	 * Appel la méthode getDatesVoyageById(String idStr)
	 *
	 */
	public List<DatesVoyage> getDatesVoyageById(String idStr) {
		long id = Long.parseLong(idStr);
		return dao.getDatesVoyageById(id);
	}

	/**
	 * getDatesVoyageCommander(String idStr)<br>
	 * Appel la méthode getDatesVoyageCommander(String idStr)
	 *
	 */
	public List<DatesVoyage> getDatesVoyageCommander(String idStr) {
		long id = Long.parseLong(idStr);
		return dao.getDatesVoyageCommander(id);
	}

	/**
	 * getDestinationById(String idStr)<br>
	 * Appel la méthode getDestinationById(String idStr)
	 *
	 */
	public List<Destination> getDestinationById(String idStr) {
		long id = Long.parseLong(idStr);
		return dao.getDestinationById(id);
	}

	/**
	 * getImagesById(String idStr)<br>
	 * Appel la méthode getDestinationById(String idStr)
	 *
	 */
	public List<Images> getImagesById(String idStr) {
		long id = Long.parseLong(idStr);
		return dao.getImagesById(id);
	}

	/**
	 * getDestinationByCommande(String idStr)<br>
	 * Appel la méthode getDestinationByCommande(String idStr)
	 *
	 */
	public List<Destination> getDestinationByCommande(String idStr) {
		long id = Long.parseLong(idStr);
		return dao.getDestinationByCommande(id);
	}	
		
}
