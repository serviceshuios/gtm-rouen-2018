package fr.bovoyage.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.sql.DataSource;

import fr.bovoyage.entites.DatesVoyage;
//import fr.bovoyage.entites.DatesVoyage;
import fr.bovoyage.entites.Destination;
import fr.bovoyage.entites.Images;

/**
 * DAO<br>
 * Contient l'ensemble des méthodes permettant la gestion des destinations et
 * des dates de voyages
 * 
 * @author Thomas & Moussa
 *
 */
public class DestinationDAO {
	private static final Logger LOG = Logger.getLogger(DestinationDAO.class.getName());
	private DataSource dataSource;

	public DestinationDAO(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	/**
	 * getAllDestinations()<br>
	 * Récupère l'image, la région, et la clef primaire associé
	 */
	public List<Destination> getAllDestinations() {
		List<Destination> destinations = new ArrayList<>();
		try (Connection connexion = dataSource.getConnection()) {
			String sequenceSql = "SELECT image, region, pk_destination " + "FROM images im, destinations de "
					+ "WHERE im.fk_destination=de.pk_destination " + "GROUP BY de.pk_destination";
			Statement stmt = connexion.createStatement();
			ResultSet rs = stmt.executeQuery(sequenceSql);
			while (rs.next()) {
				destinations.add(createDestination(rs));
			}
		} catch (SQLException e) {
			LOG.log(Level.SEVERE, "Erreur", e);
		}
		return destinations;
	}

	/**
	 * getDestinationById(long id)<br>
	 * Récupère la région, la description et la clef primaire associé à la pk
	 * choisie
	 */
	public List<Destination> getDestinationById(long id) {
		List<Destination> destinations = new ArrayList<>();
		try (Connection connexion = dataSource.getConnection()) {
			String sequenceSQL = "SELECT * FROM destinations WHERE pk_destination = ?";
			PreparedStatement pstmt = connexion.prepareStatement(sequenceSQL);
			pstmt.setLong(1, id);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				destinations.add(createDestinationById(rs));
			}
		} catch (SQLException e) {
			LOG.log(Level.SEVERE, "Erreur", e);
		}
		return destinations;
	}


	/**
	 * getDestinationByCommande(long id)<br>
	 * Récupère la région associé à la pk_date_voyage choisie
	 */
	public List<Destination> getDestinationByCommande(long id) {
		List<Destination> destinations = new ArrayList<>();

		try (Connection connexion = dataSource.getConnection()) {
			String sequenceSQL = "SELECT de.region " + "FROM destinations de, dates_voyages dv "
					+ "WHERE de.pk_destination=dv.fk_destination " + "AND dv.pk_date_voyage = ? "
					+ "GROUP BY de.region";
			PreparedStatement pstmt = connexion.prepareStatement(sequenceSQL);
			pstmt.setLong(1, id);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				destinations.add(createDestinationByCommande(rs));
			}
		} catch (SQLException e) {
			LOG.log(Level.SEVERE, "Erreur", e);
		}
		return destinations;

	}


	/**
	 * getDatesVoyageById(long id)<br>
	 * Récupère la date de départ, de retour, et le prix associé à la fk_destination
	 * choisie
	 */
	public List<DatesVoyage> getDatesVoyageById(long id) {
		List<DatesVoyage> datesVoyages = new ArrayList<>();
		try (Connection connexion = dataSource.getConnection()) {
			String sequenceSQL = "SELECT * FROM dates_voyages WHERE fk_destination = ?";
			PreparedStatement pstmt = connexion.prepareStatement(sequenceSQL);
			pstmt.setLong(1, id);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				datesVoyages.add(createDatesVoyageId(rs));
			}
		} catch (SQLException e) {
			LOG.log(Level.SEVERE, "Erreur", e);
		}
		return datesVoyages;
	}


	/**
	 * getDatesVoyageCommander(long id)<br>
	 * Récupère la date de départ, de retour, et le prix associé à la pk_date_voyage
	 * choisie
	 */
	public List<DatesVoyage> getDatesVoyageCommander(long id) {
		List<DatesVoyage> datesVoyages = new ArrayList<>();
		try (Connection connexion = dataSource.getConnection()) {
			String sequenceSQL = "SELECT * FROM dates_voyages WHERE pk_date_voyage = ? ";
			PreparedStatement pstmt = connexion.prepareStatement(sequenceSQL);
			pstmt.setLong(1, id);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				datesVoyages.add(createDatesVoyageId(rs));
			}
		} catch (SQLException e) {
			LOG.log(Level.SEVERE, "Erreur", e);
		}
		return datesVoyages;
	}


	/**
	 * getImagesById(long id)<br>
	 * Récupère la liste d'images associé à la fk_destination choisie
	 */
	public List<Images> getImagesById(long id) {
		List<Images> images = new ArrayList<>();
		try (Connection connexion = dataSource.getConnection()) {
			String sequenceSQL = "SELECT * FROM images WHERE fk_destination = ? ";
			PreparedStatement pstmt = connexion.prepareStatement(sequenceSQL);
			pstmt.setLong(1, id);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				images.add(createImagesById(rs));
			}
		} catch (SQLException e) {
			LOG.log(Level.SEVERE, "Erreur", e);
		}
		return images;
	}

	/**
	 * createDatesVoyageId(ResultSet rs)<br>
	 * Remplie la liste de voyages avec la pk, la fk, la date de départ, la date de
	 * retour et le prixHT
	 */
	private DatesVoyage createDatesVoyageId(ResultSet rs) throws SQLException {
		DatesVoyage datesVoyages = new DatesVoyage();
		datesVoyages.setId_pk(rs.getLong("pk_date_voyage"));
		datesVoyages.setId(rs.getLong("fk_destination"));
		datesVoyages.setDateAller(rs.getDate("date_depart"));
		datesVoyages.setDateRetour(rs.getDate("date_retour"));
		datesVoyages.setPrixHT(rs.getDouble("prixHT"));
		return datesVoyages;
	}


	/**
	 * createDestination(ResultSet rs)<br>
	 * Remplie la liste de destination avec la pk, la region, et l'image
	 */
	private Destination createDestination(ResultSet rs) throws SQLException {
		Destination destination = new Destination();
		destination.setId(rs.getLong("pk_destination"));
		destination.setRegion(rs.getString("region"));
		destination.setImage(rs.getString("image"));
		return destination;
	}

	/**
	 * createDestinationById(ResultSet rs)<br>
	 * Remplie la liste de destination avec la pk, la region, la description
	 */
	private Destination createDestinationById(ResultSet rs) throws SQLException {
		Destination destination = new Destination();
		destination.setId(rs.getLong("pk_destination"));
		destination.setRegion(rs.getString("region"));
		destination.setDescription(rs.getString("description"));
		return destination;
	}

	/**
	 * createImagesById(ResultSet rs)<br>
	 * Remplie la liste d'image avec la pk, le nom de l'image
	 */
	private Images createImagesById(ResultSet rs) throws SQLException {
		Images images = new Images();
		images.setId(rs.getLong("fk_destination"));
		images.setImage(rs.getString("image"));
		return images;
	}

	/**
	 * createDestinationByCommande(ResultSet rs)<br>
	 * Remplie la liste de destination avec la region
	 */
	private Destination createDestinationByCommande(ResultSet rs) throws SQLException {
		Destination destination = new Destination();
		destination.setRegion(rs.getString("region"));
		return destination;
	}

}
