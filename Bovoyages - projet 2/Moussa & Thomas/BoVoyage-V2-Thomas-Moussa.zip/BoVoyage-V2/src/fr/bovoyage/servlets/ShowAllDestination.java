package fr.bovoyage.servlets;

import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import fr.bovoyage.entites.Destination;
import fr.bovoyage.service.GestionDestinationService;

/**
 * DetailDestinationServlet<br>
 * Contient l'appel de la page JSP pour la liste des déstinations
 * 
 * @author Thomas & Moussa
 *
 */
@WebServlet("/ShowAllDestination")
public class ShowAllDestination extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static GestionDestinationService service;

	@Resource(name = "jdbc/bovoyages")
	private DataSource dataSource;

	@Override
	public void init() throws ServletException {
		service = new GestionDestinationService(dataSource);
	}

	/**
	 * doGet(...)<br>
	 * Renvoie la liste des régions
	 *
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		List<Destination> destinations = service.getAllDestinations();
		request.setAttribute("destinations", destinations);
		String page = "/show_all_destination.jsp";
		RequestDispatcher rd = getServletContext().getRequestDispatcher(page);
		rd.forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
