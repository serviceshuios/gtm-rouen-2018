package fr.bovoyage.servlets;

import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import fr.bovoyage.entites.DatesVoyage;
import fr.bovoyage.entites.Destination;
import fr.bovoyage.entites.Images;
import fr.bovoyage.service.GestionDestinationService;
/**
 * DetailDestinationServlet<br>
 * Contient l'appel de la page JSP pour les détails d'une commande
 * 
 * @author Thomas & Moussa
 *
 */
@WebServlet("/DetailDestinationServlet")
public class DetailDestinationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static GestionDestinationService service;

	@Resource(name = "jdbc/bovoyages")
	private DataSource dataSource;

	@Override
	public void init() throws ServletException {
		service = new GestionDestinationService(dataSource);
	}

	/**
	 * doGet(...)<br>
	 * Renvoie les dates de voyages et destinations et images
	 *
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String idStr = request.getParameter("id");
		request.setAttribute("idStr", idStr);

		List<DatesVoyage> datesVoyages = service.getDatesVoyageById(idStr);
		request.setAttribute("datesVoyages", datesVoyages);
		
		List<Destination> destinations = service.getDestinationById(idStr);
		request.setAttribute("destinations", destinations);
		
		List<Images> images = service.getImagesById(idStr);
		request.setAttribute("images", images);

		String page = "/detail_destination_date.jsp";
		RequestDispatcher rd = getServletContext().getRequestDispatcher(page);
		rd.forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
