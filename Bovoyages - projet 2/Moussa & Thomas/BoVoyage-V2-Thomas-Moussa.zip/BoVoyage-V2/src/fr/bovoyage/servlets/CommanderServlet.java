package fr.bovoyage.servlets;

import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import fr.bovoyage.entites.DatesVoyage;
import fr.bovoyage.entites.Destination;
import fr.bovoyage.service.GestionDestinationService;

/**
 * CommanderServlet <br>
 * Contient l'appel de la page JSP pour les commandes de voyages
 * 
 * @author Thomas & Moussa
 *
 */
@WebServlet("/CommanderServlet")
public class CommanderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static GestionDestinationService service;

	@Resource(name = "jdbc/bovoyages")
	private DataSource dataSource;

	@Override
	public void init() throws ServletException {
		service = new GestionDestinationService(dataSource);
	}

	/**
	 * doGet(...)<br>
	 * Renvoie les dates de voyages et destinations
	 *
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String idStr = request.getParameter("id");
		request.setAttribute("idStr", idStr);

		List<DatesVoyage> datesVoyages = service.getDatesVoyageCommander(idStr);
		request.setAttribute("datesVoyages", datesVoyages);

		List<Destination> destinations = service.getDestinationByCommande(idStr);
		request.setAttribute("destinations", destinations);

		String page = "/commander.jsp";
		RequestDispatcher rd = getServletContext().getRequestDispatcher(page);
		rd.forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
