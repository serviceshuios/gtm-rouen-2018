package fr.bovoyage.entites;

import java.util.Date;

/**
 * Affiche les informatons de voyage pour une destination<br>
 * <ul>
 * <li>date aller</li>
 * <li>date retour</li>
 * <li>prix du voyage</li>
 * </ul>
 * 
 * @author Thomas & Moussa
 *
 */
public class DatesVoyage {
	private long id;
	private long id_pk;
	private Date dateAller;
	private Date dateRetour;
	private double prixHT;

	public DatesVoyage() {
	}

	public DatesVoyage(Date dateAller, Date dateRetour, double prixHT) {
		this.dateAller = dateAller;
		this.dateRetour = dateRetour;
		this.prixHT = prixHT;
	}

	/**
	 * ID de synchronisation avec la clé étrangère
	 * 
	 * @return
	 */
	public long getId() {
		return id;
	}

	/**
	 * ID de synchronisation avec la clé étrangère
	 * <h3>Ne doit pas être mis à jour en dehors du DAO</h3>
	 * 
	 * @param id
	 */
	public void setId(long id) {
		this.id = id;
	}

	/**
	 * Date de départ du voyage
	 * 
	 * @return
	 */
	public Date getDateAller() {
		return dateAller;
	}

	/**
	 * Date de départ du voyage
	 * 
	 * @param dateAller
	 */
	public void setDateAller(Date dateAller) {
		this.dateAller = dateAller;
	}

	/**
	 * Date de retour du voyage
	 * 
	 * @return
	 */
	public Date getDateRetour() {
		return dateRetour;
	}

	/**
	 * Date de retour du voyage
	 * 
	 * @param dateRetour
	 */
	public void setDateRetour(Date dateRetour) {
		this.dateRetour = dateRetour;
	}

	/**
	 * Prix unitaire du voyage
	 * 
	 * @return
	 */
	public double getPrixHT() {
		return prixHT;
	}

	/**
	 * Prix unitaire du voyage
	 * 
	 * @param prixHT
	 */
	public void setPrixHT(double prixHT) {
		this.prixHT = prixHT;
	}

	/**
	 * ID de synchronisation avec la clé primaire
	 * 
	 * @return
	 */
	public long getId_pk() {
		return id_pk;
	}

	/**
	 * ID de synchronisation avec la clé primaire
	 * <h3>Ne doit pas être mis à jour en dehors du DAO</h3>
	 * 
	 * @param id_pk
	 */
	public void setId_pk(long id_pk) {
		this.id_pk = id_pk;
	}

}
