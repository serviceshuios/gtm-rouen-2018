package fr.bovoyage.entites;

import java.util.ArrayList;
import java.util.List;

/**
 * Affiche les informatons de la destionation du voyage <br>
 * <ul>
 * <li>region</li>
 * <li>description</li>
 * <li>image</li>
 * </ul>
 * 
 * @author Thomas & Moussa
 *
 */
public class Destination {
	private long id;
	private String region;
	private String description;
	private String image;
	private List<DatesVoyage> datesVoyages = new ArrayList<>();

	public Destination() {
	}

	public Destination(String region, String description) {
		this.region = region;
		this.description = description;
	}
	/**
	 * ID de synchronisation avec la clé primaire
	 * 
	 * @return
	 */
	public long getId() {
		return id;
	}

	/**
	 * ID de synchronisation avec la clé primaire
	 * <h3>Ne doit pas être mis à jour en dehors du DAO</h3>
	 * 
	 * @param id
	 */
	public void setId(long id) {
		this.id = id;
	}

	public void addDatesVoyage(DatesVoyage dates) {
		datesVoyages.add(dates);
	}
	/**
	 * Région du voyage
	 * 
	 * @return
	 */
	public String getRegion() {
		return region;
	}
	/**
	 * Région du voyage
	 * 
	 * @param region
	 */
	public void setRegion(String region) {
		this.region = region;
	}
	/**
	 * Description du voyage
	 * 
	 * @return
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * Description du voyage
	 * 
	 * @param region
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	public List<DatesVoyage> getDatesVoyages() {
		return datesVoyages;
	}

	public void setDatesVoyages(List<DatesVoyage> datesVoyages) {
		this.datesVoyages = datesVoyages;
	}

	/**
	 * image associé à la région du voyage
	 * 
	 * @return
	 */
	public String getImage() {
		return image;
	}
	/**
	 * image associé à la région du voyage
	 * 
	 * @param image
	 */
	public void setImage(String image) {
		this.image = image;
	}

}
