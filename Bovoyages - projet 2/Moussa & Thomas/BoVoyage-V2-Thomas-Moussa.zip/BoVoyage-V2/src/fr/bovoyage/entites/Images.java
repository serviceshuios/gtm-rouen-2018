package fr.bovoyage.entites;

public class Images {
	private long id;
	private String image;

	public Images() {

	}

	/**
	 * ID de synchronisation avec la clé primaire
	 * 
	 * @return
	 */
	public long getId() {
		return id;
	}

	/**
	 * ID de synchronisation avec la clé primaire
	 * <h3>Ne doit pas être mis à jour en dehors du DAO</h3>
	 * 
	 * @param id
	 */
	public void setId(long id) {
		this.id = id;
	}

	/**
	 * image associé à la région du voyage
	 * 
	 * @return
	 */
	public String getImage() {
		return image;
	}

	/**
	 * image associé à la région du voyage
	 * 
	 * @param image
	 */
	public void setImage(String image) {
		this.image = image;
	}

}
