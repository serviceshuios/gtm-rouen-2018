package fr.gtm.jeu.des;

public class MainJeu {

	public static void main(String[] args) {
		Joueur toto = new Joueur();
		Gobelet g = new Gobelet();

		for (int j = 0; j < 10; j = j + 1) {
			toto.jouer(g);
			int r = g.getValeur();
			System.out.println(r);
			if (g.isValeursIdentiques() == true) {
				System.out.println("valeurs identiques");
			} else {
				System.out.println("valeurs différentes");
			}
		}
	}

}
