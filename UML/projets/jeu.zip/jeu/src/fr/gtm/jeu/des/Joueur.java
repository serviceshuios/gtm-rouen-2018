package fr.gtm.jeu.des;

public class Joueur {
	private String nom;

	
	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}
	
	public void jouer(Gobelet gobelet) {
		gobelet.retourner();
	}
}
