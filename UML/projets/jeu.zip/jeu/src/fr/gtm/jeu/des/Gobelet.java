package fr.gtm.jeu.des;

public class Gobelet {
	private De de1 = new De();
	private De de2 = new De();
	
	public void retourner() {
		de1.lancer();
		de2.lancer();
	}
	
	public int getValeur() {
		int r = de1.getValeur() + de2.getValeur();
		return r;
	}
	
	public boolean isValeursIdentiques() {
		return de1.getValeur() == de2.getValeur();
	}
	
	
}
