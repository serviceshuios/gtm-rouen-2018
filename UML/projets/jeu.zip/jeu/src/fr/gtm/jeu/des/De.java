package fr.gtm.jeu.des;

import java.util.Random;

public class De {
	// quel que soit le nombre de dés, la 
	// même instance de Random est utilisé par
	// tous les dés
	private static Random rand = new Random();
	private int nbFaces = 6;
	private int valeur;
	
	public void lancer() {
		valeur = rand.nextInt(nbFaces)+1;
	}
	public int getNbFaces() {
		return nbFaces;
	}
	public int getValeur() {
		return valeur;
	}
	
	
}
