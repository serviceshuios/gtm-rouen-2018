package fr.gtm.jeu.des;

public class MainTest {

	public static void main(String[] args) {
		int i =0;
		
		while(i<10) {
			System.out.println("while : " +i);
			i = i + 1;
		}
		
		for(int j=0 ; j<10 ;j = j+1) {
			System.out.println("for : " +j);
		}

	}

}
