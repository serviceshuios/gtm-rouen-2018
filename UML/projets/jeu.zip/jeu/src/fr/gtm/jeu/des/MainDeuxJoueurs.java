package fr.gtm.jeu.des;

public class MainDeuxJoueurs {

	public static void main(String[] args) {
		Joueur j1 = new Joueur();
		j1.setNom("Gaston");

		Joueur j2 = new Joueur();
		j2.setNom("Adèle");

		Gobelet gobelet = new Gobelet();
		Joueur gagnant = null;
		while (true) {
			j1.jouer(gobelet);
			if (gobelet.isValeursIdentiques() == true) {
				gagnant=j1;
				break;
			}
			j2.jouer(gobelet);
			if (gobelet.isValeursIdentiques() == true) {
				gagnant = j2;
				break;
			}
		}
		System.out.println(gagnant.getNom() + " a gagné");

	}

}
