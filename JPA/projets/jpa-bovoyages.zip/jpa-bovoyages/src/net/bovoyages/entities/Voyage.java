package net.bovoyages.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="voyages")
public class Voyage {
	@Id
	@Column(name="pk_voyage")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	private String region;
	private String descriptif;
	
	@ManyToOne(cascade= {CascadeType.PERSIST,CascadeType.MERGE})
	@JoinColumn(name="fk_dates_voyage")
	private DatesVoyage datesVoyage;
	
	@ManyToMany(cascade= {CascadeType.PERSIST,CascadeType.MERGE})
	@JoinTable(name="voyages_voyageurs",
			joinColumns=@JoinColumn(name="fk_voyage"),
			inverseJoinColumns=@JoinColumn(name="fk_voyageur"))	
	private List<Voyageur> voyageurs = new ArrayList<>();
	
	@ManyToOne(cascade= {CascadeType.PERSIST,CascadeType.MERGE})
	@JoinColumn(name="fk_client")
	private Client client;
	
	public Voyage() {}
	
	public Voyage(String region) {
		this.region = region;
	}

	public Voyage(String region, String descriptif) {
		this.region = region;
		this.descriptif = descriptif;
	}
	
	public void add(Voyageur voyageur) {
		voyageurs.add(voyageur);
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public List<Voyageur> getVoyageurs() {
		return voyageurs;
	}
	public void setVoyageurs(List<Voyageur> voyageurs) {
		this.voyageurs = voyageurs;
	}
	public Client getClient() {
		return client;
	}
	public void setClient(Client client) {
		this.client = client;
	}

	public DatesVoyage getDatesVoyage() {
		return datesVoyage;
	}

	public void setDatesVoyage(DatesVoyage datesVoyage) {
		this.datesVoyage = datesVoyage;
	}

	public String getDescriptif() {
		return descriptif;
	}

	public void setDescriptif(String descriptif) {
		this.descriptif = descriptif;
	}
	
	
}
