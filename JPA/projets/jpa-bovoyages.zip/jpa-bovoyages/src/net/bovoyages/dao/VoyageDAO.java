package net.bovoyages.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import net.bovoyages.entities.DatesVoyage;
import net.bovoyages.entities.Voyage;

public class VoyageDAO {
	private EntityManagerFactory emf;

	public VoyageDAO(EntityManagerFactory emf) {
		this.emf = emf;
	}
	
	public Voyage getVoyageById(int id) {
		EntityManager em = emf.createEntityManager();
		Voyage v = em.find(Voyage.class, id);
		em.close();
		return v;
	}
	
	public void save(Voyage voyage) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		if(voyage.getDatesVoyage() != null) {
			DatesVoyage dv = em.find(DatesVoyage.class, voyage.getDatesVoyage().getId());
			voyage.setDatesVoyage(dv);
		}
		em.persist(voyage);
		em.getTransaction().commit();
		em.close();
	}
	
	public void update(Voyage voyage) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.merge(voyage);
		em.getTransaction().commit();
		em.close();
	}
	
	public void delete(Voyage voyage) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		Voyage v = em.find(Voyage.class, voyage.getId());
		em.remove(v);
		em.getTransaction().commit();
		em.close();
	}

}
