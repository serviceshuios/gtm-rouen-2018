package net.bovoyages.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import net.bovoyages.entities.DatesVoyage;

public class DatesVoyageDAO {
	private EntityManagerFactory emf;

	public DatesVoyageDAO(EntityManagerFactory emf) {
		this.emf = emf;
	}
	
	public DatesVoyage getDatesVoyageById(int id) {
		EntityManager em = emf.createEntityManager();
		DatesVoyage dv = em.find(DatesVoyage.class, id);
		em.close();
		return dv;
	}
}
