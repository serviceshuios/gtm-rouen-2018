package net.bovoyages.dao;

import static org.junit.Assert.*;

import java.util.Date;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import net.bovoyages.entities.Client;
import net.bovoyages.entities.DatesVoyage;
import net.bovoyages.entities.Voyage;
import net.bovoyages.entities.Voyageur;

public class VoyageDAOTest {
	private static EntityManagerFactory emf;
	private static final String unitName = "bovoyages";

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		emf = Persistence.createEntityManagerFactory(unitName);	
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		emf.close();
	}

	@Test
	public void testVoyageDAO() {
		VoyageDAO dao = new VoyageDAO(emf);
		assertNotNull(dao);
	}
	
	@SuppressWarnings("deprecation")
	private Voyage createVoyage() {
		DatesVoyageDAO datesVoyageDAO = new DatesVoyageDAO(emf);
		Voyage voyage = new Voyage("Bretagne","Bevet Breizh");
		Client client = new Client("Gaston and Co");
		voyage.setClient(client);
		Voyageur v1 = new Voyageur("M", "LAGAFFE", "Gaston", new Date(1957,28,1));
		Voyageur v2 = new Voyageur("Mme", "LAGAFFE", "Gastonne", new Date(1960,22,2));
		voyage.add(v1);
		voyage.add(v2);
		
		DatesVoyage dv = datesVoyageDAO.getDatesVoyageById(1);
		voyage.setDatesVoyage(dv);
		
		return voyage;
	}

	@Test
	public void testSave() {
		VoyageDAO voyageDAO = new VoyageDAO(emf);
		
		Voyage voyage = createVoyage();
		
		voyageDAO.save(voyage);
		assertTrue(true);
	}
	
	@Test
	public void testGetVoyageById() {
		VoyageDAO voyageDAO = new VoyageDAO(emf);
		Voyage voyage = createVoyage();		
		voyageDAO.save(voyage);
		voyage = voyageDAO.getVoyageById(voyage.getId());
		assertNotNull(voyage);
	}
	
	@Test
	public void testUpdate() {
		VoyageDAO voyageDAO = new VoyageDAO(emf);
		Voyage voyage = createVoyage();		
		voyageDAO.save(voyage);
		int id = voyage.getId();
		voyage.setRegion("Normandie");
		voyageDAO.update(voyage);	
		voyage = voyageDAO.getVoyageById(id);
		assertEquals("Normandie", voyage.getRegion());
	}
	
	@Test
	public void testDelete() {
		VoyageDAO voyageDAO = new VoyageDAO(emf);
		Voyage voyage = createVoyage();
		voyageDAO.save(voyage);
		int id = voyage.getId();
		voyageDAO.delete(voyage);
		voyage = voyageDAO.getVoyageById(id);
		assertNull(voyage);
	}
	

}
