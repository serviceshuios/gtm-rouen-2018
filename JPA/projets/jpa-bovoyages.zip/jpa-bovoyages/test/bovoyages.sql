SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

CREATE DATABASE IF NOT EXISTS `bovoyages` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `bovoyages`;


CREATE TABLE `clients` (
  `pk_client` int(11) NOT NULL,
  `nom` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


TRUNCATE TABLE `clients`;

CREATE TABLE `dates_voyages` (
  `pk_date_voyage` int(11) NOT NULL,
  `date_depart` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_retour` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `prixHT` double NOT NULL DEFAULT '0',
  `fk_destination` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


TRUNCATE TABLE `dates_voyages`;


INSERT INTO `dates_voyages` (`pk_date_voyage`, `date_depart`, `date_retour`, `prixHT`, `fk_destination`) VALUES
(1, '2019-06-12 00:00:00', '2019-06-24 00:00:00', 359, 1),
(2, '2019-08-01 00:00:00', '2019-08-15 00:00:00', 1450, 1),
(3, '2019-09-03 00:00:00', '2019-09-15 00:00:00', 1420, 1),
(4, '2019-06-03 00:00:00', '2019-06-15 00:00:00', 1250, 2),
(5, '2019-07-08 00:00:00', '2019-07-18 00:00:00', 1300, 2),
(6, '2019-07-02 00:00:00', '2019-07-15 00:00:00', 1700, 3),
(7, '2019-11-12 00:00:00', '2019-11-25 00:00:00', 1890, 3),
(8, '2019-12-27 00:00:00', '2019-01-10 00:00:00', 2200, 4),
(9, '2018-12-03 00:00:00', '2018-10-10 00:00:00', 1000, 1),
(10, '2018-10-31 00:00:00', '2018-10-24 00:00:00', 3000, 5);


CREATE TABLE `destinations` (
  `pk_destination` int(11) NOT NULL,
  `region` varchar(50) NOT NULL DEFAULT '',
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


TRUNCATE TABLE `destinations`;


INSERT INTO `destinations` (`pk_destination`, `region`, `description`) VALUES
(1, 'Guadeloupe', 'Dans un site exceptionnel,en bordure d\'un petit lagon turquoise, tout est réuni pour un séjour paradisiaque. Découvrez merveilles de la grand terre et basse terre, les joies des plongées dans la réserve naturelles.'),
(2, 'Saint-Barthélémy', 'Imaginez une île où il fait 26 à 28 °C toute l\'année. Baignez vous dans une eau turquoise.'),
(3, 'Birmanie', 'La Birmanie est un pays passionnant pour tous ceux qui s’intéressent à l\'art, aux civilisations, à l;hindouisme. Ce pays s\'ouvre et a conservé toute la richesse de son patrimoine culturel. Visitez les temples, les marchés, ...'),
(4, 'Canada', 'Découvrez la nature généreuse et les grandes villes du Canada en toute saison, grâce aux nombreux circuits que nous avons élaborés.'),
(6, 'toto', 'titi');



CREATE TABLE `images` (
  `image` varchar(50) NOT NULL DEFAULT '',
  `fk_destination` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



TRUNCATE TABLE `images`;


INSERT INTO `images` (`image`, `fk_destination`) VALUES
('saint-barth_1.jpg', 2),
('saint-barth_2.jpg', 2),
('birmanie_1.jpg', 3),
('birmanie_2.jpg', 3),
('birmanie_3.jpg', 3),
('canada_1.jpg', 4),
('canada_2.jpg', 4),
('guadeloupe_1.jpg', 1);



CREATE TABLE `voyages` (
  `pk_voyage` int(11) NOT NULL,
  `region` text NOT NULL,
  `descriptif` text NOT NULL,
  `fk_client` int(11) DEFAULT NULL,
  `fk_dates_voyage` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



TRUNCATE TABLE `voyages`;


CREATE TABLE `voyages_voyageurs` (
  `fk_voyage` int(11) NOT NULL,
  `fk_voyageur` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



TRUNCATE TABLE `voyages_voyageurs`;


CREATE TABLE `voyageurs` (
  `pk_voyageur` int(11) NOT NULL,
  `civilite` varchar(5) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `date_naissance` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



TRUNCATE TABLE `voyageurs`;


INSERT INTO `voyageurs` (`pk_voyageur`, `civilite`, `nom`, `prenom`, `date_naissance`) VALUES
(1, 'Mr', 'qqqq', 'qqqq', '2018-10-01'),
(2, 'Mr', 'sss', 'sss', '2018-10-03');


ALTER TABLE `clients`
  ADD PRIMARY KEY (`pk_client`);


ALTER TABLE `dates_voyages`
  ADD PRIMARY KEY (`pk_date_voyage`),
  ADD KEY `pk_date_voyage` (`pk_date_voyage`);

ALTER TABLE `destinations`
  ADD PRIMARY KEY (`pk_destination`),
  ADD UNIQUE KEY `pk_destination` (`pk_destination`);

ALTER TABLE `voyages`
  ADD PRIMARY KEY (`pk_voyage`),
  ADD KEY `fk_client` (`fk_client`);

ALTER TABLE `voyages_voyageurs`
  ADD KEY `fk_voyage` (`fk_voyage`),
  ADD KEY `fk_voyageur` (`fk_voyageur`);

ALTER TABLE `voyageurs`
  ADD PRIMARY KEY (`pk_voyageur`);


ALTER TABLE `clients`
  MODIFY `pk_client` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `dates_voyages`
  MODIFY `pk_date_voyage` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

ALTER TABLE `destinations`
  MODIFY `pk_destination` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

ALTER TABLE `voyages`
  MODIFY `pk_voyage` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `voyageurs`
  MODIFY `pk_voyageur` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

